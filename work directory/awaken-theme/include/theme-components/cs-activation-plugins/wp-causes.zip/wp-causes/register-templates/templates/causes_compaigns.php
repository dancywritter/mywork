<?php
global $post, $current_user, $cs_theme_options;
if(isset($_GET['uid']) && $_GET['uid'] <> ''){
	 $uid = absint($_GET['uid']);
} else {
	$uid= $current_user->ID;
}
$cause_pagination = "Show Pagination";
$paypal_currency_sign = $cs_theme_options['paypal_currency_sign'];
$cs_compaigns_text = $cs_theme_options['cs_compaigns_text'];
$cs_page_id = $cs_theme_options['cs_dashboard'];
$cs_cause_campaigns_allow = $cs_theme_options['cs_cause_campaigns_allow'];
?>
<div class="cs-section-title">
    <h2><?php _e('My Campaigns','Cause');?></h2>
</div>
<div class="rich_editor_text has-border">
    <p><?php echo esc_textarea($cs_compaigns_text);?></p>
    <?php 
	if(isset($cs_cause_campaigns_allow) && $cs_cause_campaigns_allow == 'on'){
		$add_compaigns_link = add_query_arg( array('action'=>'add-compaigns','uid'=>$uid), get_permalink($cs_page_id) );
		 ?>
		<a href="<?php echo esc_url($add_compaigns_link);?>" class="btn-style1"><i class="fa fa-database"></i><?php _e('Start a new compaign','Cause');?></a>
		<?php
	}
	?>
</div>
<div class="my-courses">
<?php
	$argsss = array(
				'posts_per_page'			=> "-1",
				'post_type'					=> 'causes',
				'post_status'				=> array('publish', 'private'),
				'meta_key'					=> 'cause_organizer',
				'meta_value'				=> $uid,
				'meta_compare'				=> "=",
				'orderby'					=> 'ID',
				'order'						=> 'ASC',
			);
	 $custom_query_count = new WP_Query($argsss);
	 $count_post = $custom_query_count->post_count;
	 
	 $args = array(
				'posts_per_page'			=> "10",
				'paged'						=> $_GET['page_id_all'],
				'post_type'					=> 'causes',
				'post_status'				=> array('publish', 'private'),
				'meta_key'					=> 'cause_organizer',
				'meta_value'				=> $uid,
				'meta_compare'				=> "=",
				'orderby'					=> 'ID',
				'order'						=> 'ASC',
			);
	 $custom_query = new WP_Query($args);
	
	 if ( $custom_query->have_posts() <> "" ) {
		  while ( $custom_query->have_posts() ): $custom_query->the_post();
		  $goal_amount = get_post_meta($post->ID, "cs_cause_goal_amount", true);
		  $goal_amount = empty($goal_amount) ? '0' : $goal_amount;
		  $raised_amount = get_post_meta($post->ID, "cs_cause_raised_amount", true);
		  $raised_amount = empty($raised_amount) ? '0' : $raised_amount;
		  $raisedPercentage	= get_post_meta($post->ID, "cs_cause_percentage_amount", true);
		  $raisedPercentage = empty($raisedPercentage) ? '0' : $raisedPercentage;
		  $image_url = cs_get_post_img_src($post->ID, 372, 279);
		  if ( $image_url == '') {
			$image_url	= get_template_directory_uri().'/assets/images/no-image4x3.jpg';
		  }
		  $cs_cause_trans = get_option('cs_cause_transaction_meta', true);
		  $likes_counter = cs_get_cause_likes();
		  ?>
            <div class="col-md-12">
                <article class="cs-causes causes-medium profile-casues">
				 <?php if ( $image_url ) { ?>
                        <figure><a href="<?php the_permalink();?>"><img alt="" src="<?php echo esc_url( $image_url );?>"></a></figure>
                  <?php }?>
                  <section>
                  	<h2><a href="<?php the_permalink();?>"><?php echo get_the_title();?></a></h2>
                    <ul class="post-option">
                      <li><?php echo esc_attr($paypal_currency_sign.$raised_amount);?> <?php _e('Raised of','Cause');?> <?php echo esc_attr($paypal_currency_sign.$goal_amount);?> <?php _e('Goal','Cause');?></li>
                    </ul>
                    <div class="skills-sec">
                      <div class="cs-progres-bar">
                        <div class="patteren">
                          <div class="cs-skillbar">
                            <div class="skillbar" data-percent="<?php echo esc_attr($raisedPercentage);?>%">
                              <div class="skillbar-bar"></div>
                            </div>
                          </div>
                          <!--patteren--> 
                        </div>
                      </div>
                  </div>
                  </section>
                  <div class="icons">
                    <ul>
                        <li><a><i class="fa fa-star"></i><span class="likes"><?php echo absint($likes_counter);?></span></a></li>
                        <?php 
						if ( current_user_can('edit_posts',$post->ID ) ) {
						$add_compaigns_link = add_query_arg( array('action'=>'add-compaigns','uid'=>$uid,'compaign_id'=>$post->ID), get_permalink($cs_page_id) );
						?>
                        <li><a title="Edit Campaign" data-placement="top" data-toggle="tooltip" href="<?php echo esc_url($add_compaigns_link);?>" id="tooltip" data-original-title="Tooltip on top"><i class="fa fa-edit"></i></a></li>
                        <?php
						}
						if ( isset($cs_cause_trans[$post->ID]) && is_array($cs_cause_trans[$post->ID]) && count($cs_cause_trans[$post->ID])>0 && $current_user->ID == $uid  ) {
						?>
                        	<li><a href="#" class="toggle" id="toggle<?php echo absint($post->ID);?>"></a></li>
                        <?php
						}
						?>
                    </ul>
                  </div>
                  <?php
					if ( isset($cs_cause_trans[$post->ID]) && is_array($cs_cause_trans[$post->ID]) && count($cs_cause_trans[$post->ID])>0  && $current_user->ID == $uid ) {
					?>
                          <div class="toggle-sec">
                            <div class="toggle-div<?php echo absint($post->ID);?>" style="display:none;">
                                <div class="cs-section-title">
                                    <h2><?php _e('Cause Donations','Cause');?></h2>
                                </div>
                                <div class="cause-donation">
                                <table>
                                    <thead>
                                        <tr>
                                            <th class="odd">#</th>
                                            <th class="even"><?php _e('Donor Name','Cause');?></th>
                                            <th class="odd"><?php _e('Date','Cause');?></th>
                                            <th class="odd"><?php _e('Donor Email','Cause');?></th>
                                            <th class="even"><?php _e('Trasection ID','Cause');?></th>
                                            <th class="odd"><?php _e('Amount','Cause');?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    	<?php
										$counter = 0;
										foreach ($cs_cause_trans[$post->ID] as $transct ){
											$counter++;
											$address_name = $transct['address_name'];
											$payment_date = $transct['payment_date'];
											$txn_id = $transct['txn_id'];
											$payer_email = $transct['payer_email'];
											$payment_gross = $transct['payment_gross'];
											if($counter%2==0){
												$class = 'even';	
											} else {
												$class = 'odd';
											}
										   ?>
                                           	<tr class="<?php echo esc_attr($class);?>">
                                                <td><?php echo absint($counter);?></td>
                                                <td><?php echo esc_attr($address_name);?></td>
                                                <td><?php echo esc_attr($payment_date);?></td>
                                                <td><?php echo esc_attr($payer_email);?></td>
                                                <td><?php echo esc_attr($txn_id);?></td>
                                                <td><?php echo esc_attr($paypal_currency_sign.$payment_gross);?></td>
                                            </tr>
                                         <?php
										}
										?>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                          </div>
					<?php
                    }
                    ?>
              </article>
            </div>
             <script type="text/javascript">
				jQuery('#toggle<?php echo esc_js($post->ID);?>').click(function($) {
					jQuery('.toggle-div<?php echo esc_js($post->ID);?>').slideToggle();
					jQuery('#toggle<?php echo esc_js($post->ID);?>').toggleClass('active');
					return false;
				});
			  </script>
         <?php
	 	endwhile;
         $qrystr = '';
         if ( $count_post > 10) {
                if ( isset($_GET['page_id']) ) { $qrystr .= "&page_id=".$cs_page_id;}
				 if ( isset($_GET['action']) ) $qrystr .= "&action=".$_GET['action'];
				 if ( isset($uid) ) $qrystr .= "&uid=".$uid;
                echo cs_pagination($count_post, 10, $qrystr);
         }
		?>
         <script type="text/javascript">
			jQuery(document).ready(function($) {
				cs_progress_bar();
			});
		  </script>
        <?php
		} else {
			echo '<h4>'.__('No Result Found','Cause').'</h4>';
		}
		?>
</div>
