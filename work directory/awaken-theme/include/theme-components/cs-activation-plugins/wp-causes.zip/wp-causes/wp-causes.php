<?php
/*
Plugin Name: wp causes
Plugin URI: http://awaken.chimpgroup.com/
Description: Awaken Cause Management
Version: 1.0
Author: ChimpStudio
Author URI: http://awaken.chimpgroup.com
License: GPL2
Copyright 2012  ChimpStudio  (email : info@ChimpStudio.com)
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2, as 
published by the Free Software Foundation.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, United Kingdom
*/
if(!class_exists('wp_causes'))
{
    class wp_causes
    {
		public $plugin_url;
        /**
         * Construct
         */
        public function __construct()
        {
			global $post,$wp_query,$cs_theme_options;
			$cs_theme_options = get_option('cs_theme_options');	
			$this->plugin_url = plugin_dir_url( __FILE__ );
			require_once('register-templates/class-register-templates.php');
			
			if(class_exists('awaken_regiser_templates')){
				$awaken_regiser_templates = new awaken_regiser_templates();
			}
			require_once('causes/post_type_causes.php');
			if(class_exists('post_type_causes')){
				$course_object = new post_type_causes();
				require_once('causes/causes-functions.php');
				require_once('causes/cause-listing-shortcodes.php');
			}
			require_once ('awaken-login/login-functions.php');
			require_once ('awaken-login/login-forms.php');
			require_once ('awaken-login/shortcodes.php');
			if(isset($cs_theme_options) && is_array($cs_theme_options) && count($cs_theme_options)){
				require_once ('awaken-login/cs-social-login/cs_social_login.php');
				require_once ('awaken-login/cs-social-login/google/cs-google-connect.php');
			}
			require_once ('register-templates/templates/functions_profile.php');
			add_filter( 'template_include', array(&$this, 'cs_single_template_function'));
			add_action('wp_enqueue_scripts', array(&$this, 'cs_defaultfiles_plugin_enqueue'));
			add_action('admin_enqueue_scripts', array(&$this, 'cs_defaultfiles_plugin_enqueue'));
        }
		public static function plugin_url(){
			return plugin_dir_url( __FILE__ );
			
		}
        /**
         * Activate the plugin
         */
        public static function activate()
        {	
           add_option( 'cs_cause_plugin_activation', 'installed' );
		   add_option( 'cs_cause', '1' );
        } 
        /**
         * Deactivate the plugin
         */     
        static function deactivate()
        {
           delete_option( 'cs_cause_plugin_activation');
		   delete_option( 'cs_cause', false ); 
        } 
		 /**
		 * Include Default Scripts and styles
		 */  
		public function cs_defaultfiles_plugin_enqueue()
		{
			wp_enqueue_script('jquery');
			wp_enqueue_style('font-awesome_css', plugins_url('/assets/css/font-awesome.css' , __FILE__ ));
			wp_enqueue_script('cs_counter_js', plugins_url( '/assets/scripts/counter.js' , __FILE__ ), '', '', true );
			wp_enqueue_script('cause_functions_js', plugins_url( '/assets/scripts/cause_functions.js' , __FILE__ ), '', '', true );
			wp_enqueue_script('bootstrap.min_script', plugins_url( '/assets/scripts/bootstrap_min.js' , __FILE__ ), '', '', true);
			wp_enqueue_script('datetimepicker1_js', plugins_url( '/assets/scripts/jquery_datetimepicker.js' , __FILE__ ), '', '', true);
			wp_enqueue_script('socialconnect_js', plugins_url( '/awaken-login/cs-social-login/media/js/cs-connect.js' , __FILE__ ));
			wp_enqueue_style('datetimepicker1_css', plugins_url( '/assets/css/jquery_datetimepicker.css' , __FILE__ ));
			if(is_admin()){
 				wp_enqueue_style('cause_style_css', plugins_url( '/assets/css/admin_style.css' , __FILE__ ));
			}
		}
	   	/**
         * Include Single Templates
         */  
		public function cs_single_template_function( $single_template )
		{
			global $post;
			$single_path = dirname( __FILE__ );
			if ( get_post_type() == 'causes' ) {
				if ( is_single() ) {
					$single_template = plugin_dir_path( __FILE__ ) . 'causes/single-causes.php';
				}
			}
			return $single_template;
		}
    } // End Class
}

if(class_exists('wp_causes'))
{
    // instantiate the plugin class
	$cs_causes = new wp_causes();
	register_activation_hook( __FILE__, array( 'wp_causes', 'activate' ));
	register_deactivation_hook(__FILE__, array('wp_causes', 'deactivate'));
}