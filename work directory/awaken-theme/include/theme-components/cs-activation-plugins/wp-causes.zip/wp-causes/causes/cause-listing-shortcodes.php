<?php
/**
* Cause Listing Shortcode
*/ 
if (!function_exists('cs_causes_shortcode')) {
	function cs_causes_shortcode( $atts ) {
		global $post,$wpdb,$cs_xmlObject,$cs_theme_options;
		$defaults = array( 'cause_title' => '', 'cause_cat' => '','cause_view' => '','cause_type' => '','cs_cause_last_miles_percentage' => '','cause_pagination'=>'','cs_cause_excerpt' => '','cs_cause_description' => '','cs_cause_filterable' => '','cause_per_page' => '','cs_cause_class' => '','cs_cause_animation' => '');
		extract( shortcode_atts( $defaults, $atts ) );
		
		if (isset($cs_xmlObject->sidebar_layout) && $cs_xmlObject->sidebar_layout->cs_page_layout <> '' and $cs_xmlObject->sidebar_layout->cs_page_layout <> "none"){				
				$cs_cause_grid_layout = 'col-md-4';
		}else{
				$cs_cause_grid_layout = 'col-md-3';	
		}
		if(isset($cause_title) && trim($cause_title) <> ''){
			$section_title = '<div class="main-title col-md-12"><div class="cs-section-title"><h2>'.$cause_title.'</h2></div></div>';
			echo cs_allow_special_char($section_title);
		}
		if($cause_view == 'grid'){
			cs_cause_grid($atts,$cs_cause_grid_layout);
		} else if($cause_view == 'medium'){
			cs_cause_medium($atts);
		} else {
			cs_cause_classic($atts);
		}
		
	}
	add_shortcode('cs_cause', 'cs_causes_shortcode');
}
/**
* Cause Grid Shortcode
*/
if (!function_exists('cs_cause_grid')) {
	function cs_cause_grid($atts,$cs_cause_grid_layout='col-md-4')
	{
		
		global $post,$wpdb,$cs_theme_options;
		$defaults = array( 'cause_title' => '', 'cause_cat' => '','cause_view' => '','cause_type' => '','cs_cause_last_miles_percentage' => '','cause_pagination'=>'','cs_cause_excerpt' => '','cs_cause_description' => '','cs_cause_filterable' => '','cause_per_page' => '','cs_cause_class' => '','cs_cause_animation' => '');
		extract( shortcode_atts( $defaults, $atts ) );

		if ( trim($cs_cause_animation) !='' ) {
			$cs_cause_animation	= 'wow'.' '.$cs_cause_animation;
		} else {
			$cs_cause_animation	= '';
		}
		
		$CustomId	= '';
		if ( isset( $cs_cause_class ) && $cs_cause_class ) {
			$CustomId	= 'id="'.$cs_cause_class.'"';
		}
		
		date_default_timezone_set('UTC');
		$current_time = current_time('Y/m/d');
		
		ob_start();
		
		$organizer_filter = '';
		$user_meta_key				= '';
		$user_meta_value			= '';
		$meta_compare = "";
		$meta_value   = '';
		$meta_key	  = '';
		
		//==Filters
		$filter_category = '';
		$filter_tag = '';
       	
		if ( isset($_GET['filter_category']) && $_GET['filter_category'] <> '' && $_GET['filter_category'] <> '0' ) { $filter_category = $_GET['filter_category'];
		}else if(isset($cs_dcpt_post_category) && $cs_dcpt_post_category <> '' && $cs_dcpt_post_category <> '0'){
			$filter_category = $cs_dcpt_post_category;
		}
		//==Filters End
		
		if ( $cause_type == "upcoming_causes" ) { 
			$meta_compare = ">=";
			$meta_value   = $current_time;
			$meta_key	  = 'cause_end_date';
		} else if ( $cause_type == "past_causes" ) { 
			$meta_compare = "<";
			$meta_value   = $current_time;
			$meta_key	  = 'cause_end_date';
		} else if ( $cause_type == "cause-succesfully" ) { 
			$meta_compare = ">=";
			$meta_value   = '100';
			$meta_key	  = 'cs_cause_percentage_amount';
		} else if ( $cause_type == "cause-last-miles" ) { 
			$meta_compare = ">=";
			$meta_value   = $cs_cause_last_miles_percentage;
			$meta_key	  = 'cs_cause_percentage_amount';
		}
		
		if(isset($_GET['sort']) and $_GET['sort']=='asc'){
			$order	= 'ASC';
		} else{
			$order	= 'DESC';
		}
		
		if(isset($_GET['sort']) and $_GET['sort']=='alphabetical'){
			$orderby	= 'title';
			$order	    = 'ASC';
		} else{
			$orderby	= 'meta_value';
		}

		$paypal_currency_sign = isset($cs_theme_options['paypal_currency_sign'])?$cs_theme_options['paypal_currency_sign']:'$';	
		$cs_counter_causes = 0;
			
		if ( empty($_GET['page_id_all']) ) $_GET['page_id_all'] = 1;

		if ( isset($_GET['organizer']) && $_GET['organizer'] <> '' ) {
			$meta_key				= 'cause_organizer';
			$meta_value				= $_GET['organizer'];
			$meta_compare			= "=";
			$organizer_filter		= $_GET['organizer'];
		}
		    
		if ( $cause_type == "upcoming_causes" ) {
			$args = array(
				'posts_per_page'			=> "-1",
				'post_type'					=> 'causes',
				'post_status'				=> 'publish',
				'meta_key'					=> $meta_key,
				'meta_value'				=> $meta_value,
				'meta_compare'				=> $meta_compare,
				'orderby'					=> $orderby,
				'order'						=> $order,
			);
		
		} else if ( $cause_type == "past_causes" ) {
			$args = array(
				'posts_per_page'			=> "-1",
				'post_type'					=> 'causes',
				'post_status'				=> 'publish',
				'meta_key'					=> $meta_key,
				'meta_value'				=> $meta_value,
				'meta_compare'				=> $meta_compare,
				'orderby'					=> $orderby,
				'order'						=> $order,
			);
		
		} elseif ( $cause_type == "cause-succesfully" ) {
			$args = array(
				'posts_per_page'			=> "-1",
				'post_type'					=> 'causes',
				'post_status'				=> 'publish',
				'meta_key'					=> $meta_key,
				'meta_value'				=> $meta_value,
				'meta_compare'				=> $meta_compare,
				'orderby'					=> $orderby,
				'order'						=> $order,
			);
		
		} elseif ( $cause_type == "cause-last-miles" ) {
			$args = array(
				'posts_per_page'			=> "-1",
				'post_type'					=> 'causes',
				'post_status'				=> 'publish',
				'meta_key'					=> $meta_key,
				'meta_value'				=> $meta_value,
				'meta_compare'				=> $meta_compare,
				'orderby'					=> $orderby,
				'order'						=> $order,
			);
		
		} else {
			$args = array(
				'posts_per_page'			=> "-1",
				'post_type'					=> 'causes',
				'post_status'				=> 'publish',
				'orderby'					=> $orderby,
				'order'						=> $order,
			);
		
		} 
		
		if ( isset($_GET['filter_category']) && $_GET['filter_category'] <> '' && $_GET['filter_category'] <> '0' ) { 
			$causes_category_array = array('causes-category' => $_GET['filter_category']);
			$args = array_merge($args, $causes_category_array);
		
		} else if(isset($cause_cat) && $cause_cat <> '' && $cause_cat <> '0'){
			$causes_category_array = array('causes-category' => "$cause_cat");
			$args = array_merge($args, $causes_category_array);
		}
            
			$custom_query = new WP_Query($args);
            $count_post = 0;
			$counter = 1;
			$count_post = $custom_query->post_count;
			
			if ( $cause_type == "upcoming_causes") {
				
				$args = array(
					'posts_per_page'			=> "$cause_per_page",
					'paged'						=> $_GET['page_id_all'],
					'post_type'					=> 'causes',
					'post_status'				=> 'publish',
					'meta_key'					=> $meta_key,
					'meta_value'				=> $meta_value,
					'meta_compare'				=> $meta_compare,
					'orderby'					=> $orderby,
					'order'						=> $order,
				 );
			} else if ( $cause_type == "past_causes" ) {
				
					$args = array(
						'posts_per_page'			=> "$cause_per_page",
						'paged'						=> $_GET['page_id_all'],
						'post_type'					=> 'causes',
						'meta_key'					=> $meta_key,
						'meta_value'				=> $meta_value,
						'meta_compare'				=> $meta_compare,
						'orderby'					=> $orderby,
						'order'						=> $order,
					);
				
			} else if ( $cause_type == "cause-succesfully" ) {
				
					$args = array(
						'posts_per_page'			=> "$cause_per_page",
						'paged'						=> $_GET['page_id_all'],
						'post_type'					=> 'causes',
						'meta_key'					=> $meta_key,
						'meta_value'				=> $meta_value,
						'meta_compare'				=> $meta_compare,
						'orderby'					=> $orderby,
						'order'						=> $order,
					);
				
			} else if ( $cause_type == "cause-last-miles" ) {
				
					$args = array(
						'posts_per_page'			=> "$cause_per_page",
						'paged'						=> $_GET['page_id_all'],
						'post_type'					=> 'causes',
						'meta_key'					=> $meta_key,
						'meta_value'				=> $meta_value,
						'meta_compare'				=> $meta_compare,
						'orderby'					=> $orderby,
						'order'						=> $order,
					);
				
			} else {
				$args = array(
                    'posts_per_page'			=> "$cause_per_page",
					'paged'						=> $_GET['page_id_all'],
                    'post_type'					=> 'causes',
                    'post_status'				=> 'publish',
                   	'meta_key'					=> $meta_key,
                    'meta_value'				=> $meta_value,
                    'meta_compare'				=> $meta_compare,
                    'orderby'					=> $orderby,
                    'order'						=> $order,
                );
			}
		
		
		
		if ( isset($_GET['filter_category']) && $_GET['filter_category'] <> '' && $_GET['filter_category'] <> '0' ) 
		{ 
			$causes_category_array = array('causes-category' => $_GET['filter_category']);
			$args = array_merge($args, $causes_category_array);
		
		} else if(isset($cause_cat) && $cause_cat <> '' && $cause_cat <> '0'){
			$causes_category_array = array('causes-category' => "$cause_cat");
			$args = array_merge($args, $causes_category_array);
		}
		
		if(isset($filter_category) && $filter_category <> '' && $filter_category <> '0'){
				
				if ( isset($_GET['filter-tag']) ) {$filter_tag = $_GET['filter-tag'];}
				if($filter_tag <> ''){
					$causes_category_array = array('causes-category' => "$filter_category",'causes-tag' => "$filter_tag");
				}else{
					$causes_category_array = array('causes-category' => "$filter_category");
				}
				$args = array_merge($args, $causes_category_array);
			}
			
		if ( isset($_GET['filter-tag']) && $_GET['filter-tag'] <> '' && $_GET['filter-tag'] <> '0' ) {
			$filter_tag = $_GET['filter-tag'];
			if($filter_tag <> ''){
				$causes_category_array = array('causes-category' => "$filter_category",'causes-tag' => "$filter_tag");
				$args = array_merge($args, $causes_category_array);
			}
		}
		if ( isset($_GET['organizer']) && $_GET['organizer'] <> '' ) {
			$user_meta_key				= '';
			$user_meta_value			= '';
		}
		
		$user_args = array(
                    'posts_per_page'			=> "-1",
					'post_type'					=> 'causes',
					'post_status'				=> 'publish',
					'meta_key'					=> $user_meta_key,
                    'meta_value'				=> $user_meta_value,
                );
		
		$custom_query = new WP_Query($args);
		
		$user_query = new WP_Query($user_args);
		$count_post = $user_query->post_count;
		$userArray	= ''; 			
		while ( $user_query->have_posts() ) { $user_query->the_post();
			$user_id = get_post_meta($post->ID, "cause_organizer", true);			
			if (isset( $user_id ) && $user_id !='' ){
				$userArray[] = $user_id;
			}
		}
		
		
		wp_reset_postdata();
		
		cs_get_cause_filters($cause_cat,$cs_cause_filterable,$filter_category,$filter_tag,$userArray,$organizer_filter,$cs_cause_animation);
		
		if ( $custom_query->have_posts() <> "" ) {
			
			while ( $custom_query->have_posts() ): $custom_query->the_post();
			
			$width				= '372';
			$height				= '279';
			$image_url 			= cs_get_post_img_src($post->ID, $width, $height);
			$title_limit 		= 60;
			$background			= '';
			$raisedPercentage 	= 0;
			$cause_end_date 	= get_post_meta($post->ID, "cause_end_date", true);
			$goal_amount 		= get_post_meta($post->ID, "cs_cause_goal_amount", true);
			$raised_amount 		= get_post_meta($post->ID, "cs_cause_raised_amount", true);
			$raisedPercentage 	= get_post_meta($post->ID, "cs_cause_percentage_amount", true);
			$randId 			= cs_generate_random_string(5);
			
			if ( $image_url == '') {
				$image_url	= get_template_directory_uri().'/assets/images/no-image4x3.jpg';
			}
			
		?>
	   <script type="text/javascript">
		  jQuery(document).ready(function() {
			jQuery('.skillbar-<?php echo esc_js($randId);?>').each(function() {
				jQuery(this).waypoint(function(direction) {
					jQuery(this).find('.skillbar-bar').animate({
						width: jQuery(this).attr('data-percent')
					}, 2000);
				}, {
					offset: "100%",
				triggerOnce: true
				});
		   });
		  });
	   </script>
       <div class="<?php echo esc_attr( $cs_cause_grid_layout.' '.$cs_cause_animation );?>" <?php echo esc_attr( $CustomId );?>> 
        <!-- Article -->
        <article class="cs-causes causes-grid has_shapes">
          <?php if ( $image_url ) { ?>
                <figure><a href="<?php the_permalink();?>"><img alt="" src="<?php echo esc_url( $image_url );?>"></a></figure>
          <?php }?>
          <section>
            <h2><a href="<?php the_permalink();?>"><?php echo substr(get_the_title(),0, $title_limit); if(strlen(get_the_title())>$title_limit){echo '...';}?></a></h2>
            <?php if ( $cs_cause_description=='on' ){?><p><?php echo cs_get_the_excerpt($cs_cause_excerpt,false, 'Read More');?></p><?php }?>
            <div class="skills-sec">
              <div class="cs-progres-bar">
               <div class="cs-amount"> 
                    <span class="raised-amount"> <?php echo esc_attr( $paypal_currency_sign.number_format(absint($raised_amount)) );?><?php esc_html_e(' Raised','Cause');?></span>
                    <?php if ( isset( $goal_amount ) && $goal_amount !='' ) {?><span class="goal-amount"><?php echo _e('Goal ','Cause');echo esc_attr( $paypal_currency_sign.number_format(absint($goal_amount)));?></span><?php }?>
                </div>
                <div class="patteren">
                  <div class="cs-skillbar">
                    <div data-percent="<?php echo esc_attr( $raisedPercentage );?>%" class="skillbar-<?php echo esc_attr($randId);?>">
                      <div class="skillbar-bar"></div>
                    </div>
                  </div>
                  <!--patteren--> 
                </div>
              </div>
             <a class="btn-style1" href="<?php the_permalink();?>"><i class="fa fa-database"></i><?php esc_html_e('Contribute Now','Cause');?></a> </div>
          </section>
        </article>
        <!-- Article Close --> 
      </div>
	  <?php 
      
         endwhile;
         $qrystr = '';
         if ( $cause_pagination == "Show Pagination" and $count_post > $cause_per_page and $cause_per_page > 0) {
				 
				 if ( isset($_GET['organizer']) ) $qrystr .= "&amp;organizer=".$_GET['organizer'];
				 if ( isset($_GET['sort']) ) $qrystr .= "&amp;sort=".$_GET['sort'];
				 if ( isset($_GET['filter_category']) ) $qrystr .= "&amp;filter_category=".$_GET['filter_category'];
				 if ( isset($_GET['filter-tag']) ) $qrystr .= "&amp;filter-tag=".$_GET['filter-tag'];
				 if ( isset($_GET['page_id']) ) $qrystr .= "&amp;page_id=".$_GET['page_id'];
                
				 echo cs_pagination($count_post, $cause_per_page,$qrystr);
         }
	  } else {
	  	echo '<div class="col-md-12"><div class="succ_mess"><p>';
			esc_html_e('No Causes Found','Cause');
		echo '</p></div</div>';
	  }
	}
	
}
/**
* Cause Medium Shortcode
*/
if (!function_exists('cs_cause_medium')) {
	function cs_cause_medium($atts)
	{
		global $post,$wpdb;
		$defaults = array( 'column_size'=>'','cause_title' => '', 'cause_cat' => '','cause_view' => '','cause_type' => '','cs_cause_last_miles_percentage' => '','cause_pagination'=>'','cs_cause_excerpt' => '','cs_cause_filterable' => '','cause_per_page' => '','cs_cause_class' => '','cs_cause_animation' => '');
		extract( shortcode_atts( $defaults, $atts ) );

		if ( trim($cs_cause_animation) !='' ) {
			$cs_cause_animation	= 'wow'.' '.$cs_cause_animation;
		} else {
			$cs_cause_animation	= '';
		}
		
		$CustomId	= '';
		if ( isset( $cs_cause_class ) && $cs_cause_class ) {
			$CustomId	= 'id="'.$cs_cause_class.'"';
		}
		
		date_default_timezone_set('UTC');
		$current_time = current_time('Y/m/d');
		
		ob_start();
		
		$organizer_filter = '';
		$user_meta_key				= '';
		$user_meta_value			= '';
		$meta_compare = "";
		$meta_value   = '';
		$meta_key	  = '';
		
		//==Filters
		$filter_category = '';
		$filter_tag = '';
       	
		if ( isset($_GET['filter_category']) && $_GET['filter_category'] <> '' && $_GET['filter_category'] <> '0' ) { $filter_category = $_GET['filter_category'];
		}else if(isset($cs_dcpt_post_category) && $cs_dcpt_post_category <> '' && $cs_dcpt_post_category <> '0'){
			$filter_category = $cs_dcpt_post_category;
		}
		//==Filters End
		
		if ( $cause_type == "upcoming_causes" ) { 
			$meta_compare = ">=";
			$meta_value   = $current_time;
			$meta_key	  = 'cause_end_date';
		} else if ( $cause_type == "past_causes" ) { 
			$meta_compare = "<";
			$meta_value   = $current_time;
			$meta_key	  = 'cause_end_date';
		} else if ( $cause_type == "cause-succesfully" ) { 
			$meta_compare = ">=";
			$meta_value   = '100';
			$meta_key	  = 'cs_cause_percentage_amount';
		} else if ( $cause_type == "cause-last-miles" ) { 
			$meta_compare = ">=";
			$meta_value   = $cs_cause_last_miles_percentage;
			$meta_key	  = 'cs_cause_percentage_amount';
		}
		
		if(isset($_GET['sort']) and $_GET['sort']=='asc'){
			$order	= 'ASC';
		} else{
			$order	= 'DESC';
		}
		
		if(isset($_GET['sort']) and $_GET['sort']=='alphabetical'){
			$orderby	= 'title';
			$order	    = 'ASC';
		} else{
			$orderby	= 'meta_value';
		}

		$paypal_currency_sign = isset($cs_theme_options['paypal_currency_sign'])?$cs_theme_options['paypal_currency_sign']:'$';	
		$cs_counter_causes = 0;
			
		if ( empty($_GET['page_id_all']) ) $_GET['page_id_all'] = 1;

		if ( isset($_GET['organizer']) && $_GET['organizer'] <> '' ) {
			$meta_key				= 'cause_organizer';
			$meta_value				= $_GET['organizer'];
			$meta_compare			= "=";
			$organizer_filter		= $_GET['organizer'];
		}
		    
		if ( $cause_type == "upcoming_causes" ) {
			$args = array(
				'posts_per_page'			=> "-1",
				'post_type'					=> 'causes',
				'post_status'				=> 'publish',
				'meta_key'					=> $meta_key,
				'meta_value'				=> $meta_value,
				'meta_compare'				=> $meta_compare,
				'orderby'					=> $orderby,
				'order'						=> $order,
			);
		
		} else if ( $cause_type == "past_causes" ) {
			$args = array(
				'posts_per_page'			=> "-1",
				'post_type'					=> 'causes',
				'post_status'				=> 'publish',
				'meta_key'					=> $meta_key,
				'meta_value'				=> $meta_value,
				'meta_compare'				=> $meta_compare,
				'orderby'					=> $orderby,
				'order'						=> $order,
			);
		
		} elseif ( $cause_type == "cause-succesfully" ) {
			$args = array(
				'posts_per_page'			=> "-1",
				'post_type'					=> 'causes',
				'post_status'				=> 'publish',
				'meta_key'					=> $meta_key,
				'meta_value'				=> $meta_value,
				'meta_compare'				=> $meta_compare,
				'orderby'					=> $orderby,
				'order'						=> $order,
			);
		
		} elseif ( $cause_type == "cause-last-miles" ) {
			$args = array(
				'posts_per_page'			=> "-1",
				'post_type'					=> 'causes',
				'post_status'				=> 'publish',
				'meta_key'					=> $meta_key,
				'meta_value'				=> $meta_value,
				'meta_compare'				=> $meta_compare,
				'orderby'					=> $orderby,
				'order'						=> $order,
			);
		
		} else {
			$args = array(
				'posts_per_page'			=> "-1",
				'post_type'					=> 'causes',
				'post_status'				=> 'publish',
				'orderby'					=> $orderby,
				'order'						=> $order,
			);
		
		} 
		
		if ( isset($_GET['filter_category']) && $_GET['filter_category'] <> '' && $_GET['filter_category'] <> '0' ) { 
			$causes_category_array = array('causes-category' => $_GET['filter_category']);
			$args = array_merge($args, $causes_category_array);
		
		} else if(isset($cause_cat) && $cause_cat <> '' && $cause_cat <> '0'){
			$causes_category_array = array('causes-category' => "$cause_cat");
			$args = array_merge($args, $causes_category_array);
		}
            
			$custom_query = new WP_Query($args);
            $count_post = 0;
			$counter = 1;
			$count_post = $custom_query->post_count;
			
			if ( $cause_type == "upcoming_causes") {
				
				$args = array(
					'posts_per_page'			=> "$cause_per_page",
					'paged'						=> $_GET['page_id_all'],
					'post_type'					=> 'causes',
					'post_status'				=> 'publish',
					'meta_key'					=> $meta_key,
					'meta_value'				=> $meta_value,
					'meta_compare'				=> $meta_compare,
					'orderby'					=> $orderby,
					'order'						=> $order,
				 );
			} else if ( $cause_type == "past_causes" ) {
				
					$args = array(
						'posts_per_page'			=> "$cause_per_page",
						'paged'						=> $_GET['page_id_all'],
						'post_type'					=> 'causes',
						'meta_key'					=> $meta_key,
						'meta_value'				=> $meta_value,
						'meta_compare'				=> $meta_compare,
						'orderby'					=> $orderby,
						'order'						=> $order,
					);
				
			} else if ( $cause_type == "cause-succesfully" ) {
				
					$args = array(
						'posts_per_page'			=> "$cause_per_page",
						'paged'						=> $_GET['page_id_all'],
						'post_type'					=> 'causes',
						'meta_key'					=> $meta_key,
						'meta_value'				=> $meta_value,
						'meta_compare'				=> $meta_compare,
						'orderby'					=> $orderby,
						'order'						=> $order,
					);
				
			} else if ( $cause_type == "cause-last-miles" ) {
				
					$args = array(
						'posts_per_page'			=> "$cause_per_page",
						'paged'						=> $_GET['page_id_all'],
						'post_type'					=> 'causes',
						'meta_key'					=> $meta_key,
						'meta_value'				=> $meta_value,
						'meta_compare'				=> $meta_compare,
						'orderby'					=> $orderby,
						'order'						=> $order,
					);
				
			} else {
				$args = array(
                    'posts_per_page'			=> "$cause_per_page",
					'paged'						=> $_GET['page_id_all'],
                    'post_type'					=> 'causes',
                    'post_status'				=> 'publish',
                   	'meta_key'					=> $meta_key,
                    'meta_value'				=> $meta_value,
                    'meta_compare'				=> $meta_compare,
                    'orderby'					=> $orderby,
                    'order'						=> $order,
                );
			}
		
		
		
		if ( isset($_GET['filter_category']) && $_GET['filter_category'] <> '' && $_GET['filter_category'] <> '0' ) 
		{ 
			$causes_category_array = array('causes-category' => "$cause_cat");
			$args = array_merge($args, $causes_category_array);
		
		} else if(isset($cause_cat) && $cause_cat <> '' && $cause_cat <> '0'){
			$causes_category_array = array('causes-category' => "$cause_cat");
			$args = array_merge($args, $causes_category_array);
		}
		
		if(isset($filter_category) && $filter_category <> '' && $filter_category <> '0'){
				
				if ( isset($_GET['filter-tag']) ) {$filter_tag = $_GET['filter-tag'];}
				if($filter_tag <> ''){
					$causes_category_array = array('causes-category' => "$filter_category",'causes-tag' => "$filter_tag");
				}else{
					$causes_category_array = array('causes-category' => "$filter_category");
				}
				$args = array_merge($args, $causes_category_array);
			}
			
		if ( isset($_GET['filter-tag']) && $_GET['filter-tag'] <> '' && $_GET['filter-tag'] <> '0' ) {
			$filter_tag = $_GET['filter-tag'];
			if($filter_tag <> ''){
				$causes_category_array = array('causes-category' => "$filter_category",'causes-tag' => "$filter_tag");
				$args = array_merge($args, $causes_category_array);
			}
		}
		if ( isset($_GET['organizer']) && $_GET['organizer'] <> '' ) {
			$user_meta_key				= '';
			$user_meta_value			= '';
		}
		
		$user_args = array(
                    'posts_per_page'			=> "-1",
					'post_type'					=> 'causes',
					'post_status'				=> 'publish',
					'meta_key'					=> $user_meta_key,
                    'meta_value'				=> $user_meta_value,
                );
		
		$custom_query = new WP_Query($args);
		
		$user_query = new WP_Query($user_args);
		$count_post = $user_query->post_count;
		$userArray	= ''; 			
		while ( $user_query->have_posts() ) { $user_query->the_post();
			$user_id = get_post_meta($post->ID, "cause_organizer", true);			
			if (isset( $user_id ) && $user_id !='' ){
				$userArray[] = $user_id;
			}
		}
		
		
		wp_reset_postdata();
		
		cs_get_cause_filters($cause_cat,$cs_cause_filterable,$filter_category,$filter_tag,$userArray,$organizer_filter,$cs_cause_animation);
		if ( $custom_query->have_posts() <> "" ) {
			while ( $custom_query->have_posts() ): $custom_query->the_post();
			$width				= '372';
			$height				= '279';
			$image_url 			= cs_get_post_img_src($post->ID, $width, $height);
			$title_limit 		= 60;
			$background			= '';
			$raisedPercentage 	= 0;
			$cause_end_date 	= get_post_meta($post->ID, "cause_end_date", true);
			$goal_amount 		= get_post_meta($post->ID, "cs_cause_goal_amount", true);
			$raised_amount 		= get_post_meta($post->ID, "cs_cause_raised_amount", true);
			$raisedPercentage 	= get_post_meta($post->ID, "cs_cause_percentage_amount", true);
			$randId 			= cs_generate_random_string(5);
	?>
       <script type="text/javascript">
		  jQuery(document).ready(function() {
			jQuery('.skillbar-<?php echo esc_js($randId);?>').each(function() {
				jQuery(this).waypoint(function(direction) {
					jQuery(this).find('.skillbar-bar').animate({
						width: jQuery(this).attr('data-percent')
					}, 2000);
				}, {
					offset: "100%",
				triggerOnce: true
				});
		   });
		  });
	   </script>
       <div class="col-md-12 <?php echo esc_attr( $cs_cause_animation );?>" <?php echo esc_attr( $CustomId );?>> 
        <article class="cs-causes causes-medium">
          <?php if ( $image_url ) { ?>
                <figure><a href="<?php the_permalink();?>"><img alt="" src="<?php echo esc_url( $image_url );?>"></a></figure>
          <?php }?>
          <section>
            <h2><a href="<?php the_permalink();?>"><?php echo substr(get_the_title(),0, $title_limit); if(strlen(get_the_title())>$title_limit){echo '...';}?></a></h2>
            <ul class="post-option">
              <li> <i class="fa fa-calendar"></i><?php echo esc_attr( date_i18n( get_option( 'date_format' ),strtotime( $cause_end_date ) ) );?></li>
              <li><?php cs_get_categories( $cause_cat );?></li>
            </ul>
            <?php if ( $cs_cause_description=='on' ){?><p><?php echo cs_get_the_excerpt($cs_cause_excerpt,false, 'Read More');?></p><?php }?>
            <div class="skills-sec">
              <div class="cs-progres-bar">
                <div class="cs-amount"> 
                    <span class="raised-amount">
                        <?php echo esc_attr( $paypal_currency_sign.number_format(absint($raised_amount)) );?><?php esc_html_e(' Raised','Cause');?></span>
                        <?php if ( isset( $goal_amount ) && $goal_amount !='' ) {?><span class="goal-amount"><?php _e('Goal ','Cause');echo esc_attr( $paypal_currency_sign.number_format(absint($goal_amount)) );?></span><?php }?>
                </div>
                <div class="patteren">
                  <div class="cs-skillbar">
                    <div data-percent="<?php echo esc_attr( $raisedPercentage );?>%" class="skillbar-<?php echo esc_attr($randId);?>">
                      <div class="skillbar-bar"></div>
                    </div>
                  </div>
                  <!--patteren--> 
                </div>
              </div>
              <a class="btn-style1" href="<?php the_permalink();?>"><i class="fa fa-database"></i><?php esc_html_e('Contribute Now','Cause');?></a> </div>
          </section>
          <!--causes-classic--> 
        </article>
      </div>
	  <?php 
         endwhile;
         $qrystr = '';
         if ( $cause_pagination == "Show Pagination" and $count_post > $cause_per_page and $cause_per_page > 0) {
			 
				 if ( isset($_GET['organizer']) ) $qrystr .= "&amp;organizer=".$_GET['organizer'];
				 if ( isset($_GET['sort']) ) $qrystr .= "&amp;sort=".$_GET['sort'];
				 if ( isset($_GET['filter_category']) ) $qrystr .= "&amp;filter_category=".$_GET['filter_category'];
				 if ( isset($_GET['filter-tag']) ) $qrystr .= "&amp;filter-tag=".$_GET['filter-tag'];
				 if ( isset($_GET['page_id']) ) $qrystr .= "&amp;page_id=".$_GET['page_id'];
                
                 echo cs_pagination($count_post, $cause_per_page,$qrystr);
         }
	  } else {
	  	echo '<div class="col-md-12"><div class="succ_mess"><p>';
			esc_html_e('No Causes Found','Cause');
		echo '</p></div</div>';
	  }	
	}
}

/**
* Cause Classic Shortcode
*/		 
if (!function_exists('cs_cause_classic')) {
	function cs_cause_classic($atts)
	{
		global $post,$wpdb;
		$defaults = array( 'cause_title' => '', 'cause_cat' => '','cause_view' => '','cause_type' => '','cs_cause_last_miles_percentage' => '','cause_pagination'=>'','cs_cause_excerpt' => '','cs_cause_description' => '','cs_cause_filterable' => '','cause_per_page' => '','cs_cause_class' => '','cs_cause_animation' => '');
		extract( shortcode_atts( $defaults, $atts ) );

		if ( trim($cs_cause_animation) !='' ) {
			$cs_cause_animation	= 'wow'.' '.$cs_cause_animation;
		} else {
			$cs_cause_animation	= '';
		}
		
		$CustomId	= '';
		if ( isset( $cs_cause_class ) && $cs_cause_class ) {
			$CustomId	= 'id="'.$cs_cause_class.'"';
		}
		
		date_default_timezone_set('UTC');
		$current_time = current_time('Y/m/d');
		
		ob_start();
		
		$organizer_filter = '';
		$user_meta_key				= '';
		$user_meta_value			= '';
		$meta_compare = "";
		$meta_value   = '';
		$meta_key	  = '';
		
		//==Filters
		$filter_category = '';
		$filter_tag = '';
       	
		if ( isset($_GET['filter_category']) && $_GET['filter_category'] <> '' && $_GET['filter_category'] <> '0' ) { $filter_category = $_GET['filter_category'];
		}else if(isset($cs_dcpt_post_category) && $cs_dcpt_post_category <> '' && $cs_dcpt_post_category <> '0'){
			$filter_category = $cs_dcpt_post_category;
		}
		//==Filters End
		
		if ( $cause_type == "upcoming_causes" ) { 
			$meta_compare = ">=";
			$meta_value   = $current_time;
			$meta_key	  = 'cause_end_date';
		} else if ( $cause_type == "past_causes" ) { 
			$meta_compare = "<";
			$meta_value   = $current_time;
			$meta_key	  = 'cause_end_date';
		} else if ( $cause_type == "cause-succesfully" ) { 
			$meta_compare = ">=";
			$meta_value   = '100';
			$meta_key	  = 'cs_cause_percentage_amount';
		} else if ( $cause_type == "cause-last-miles" ) { 
			$meta_compare = ">=";
			$meta_value   = $cs_cause_last_miles_percentage;
			$meta_key	  = 'cs_cause_percentage_amount';
		}
		
		if(isset($_GET['sort']) and $_GET['sort']=='asc'){
			$order	= 'ASC';
		} else{
			$order	= 'DESC';
		}
		
		if(isset($_GET['sort']) and $_GET['sort']=='alphabetical'){
			$orderby	= 'title';
			$order	    = 'ASC';
		} else{
			$orderby	= 'meta_value';
		}

		$paypal_currency_sign = isset($cs_theme_options['paypal_currency_sign'])?$cs_theme_options['paypal_currency_sign']:'$';	
		$cs_counter_causes = 0;
			
		if ( empty($_GET['page_id_all']) ) $_GET['page_id_all'] = 1;

		if ( isset($_GET['organizer']) && $_GET['organizer'] <> '' ) {
			$meta_key				= 'cause_organizer';
			$meta_value				= $_GET['organizer'];
			$meta_compare			= "=";
			$organizer_filter		= $_GET['organizer'];
		}
		    
		if ( $cause_type == "upcoming_causes" ) {
			$args = array(
				'posts_per_page'			=> "-1",
				'post_type'					=> 'causes',
				'post_status'				=> 'publish',
				'meta_key'					=> $meta_key,
				'meta_value'				=> $meta_value,
				'meta_compare'				=> $meta_compare,
				'orderby'					=> $orderby,
				'order'						=> $order,
			);
		
		} else if ( $cause_type == "past_causes" ) {
			$args = array(
				'posts_per_page'			=> "-1",
				'post_type'					=> 'causes',
				'post_status'				=> 'publish',
				'meta_key'					=> $meta_key,
				'meta_value'				=> $meta_value,
				'meta_compare'				=> $meta_compare,
				'orderby'					=> $orderby,
				'order'						=> $order,
			);
		
		} elseif ( $cause_type == "cause-succesfully" ) {
			$args = array(
				'posts_per_page'			=> "-1",
				'post_type'					=> 'causes',
				'post_status'				=> 'publish',
				'meta_key'					=> $meta_key,
				'meta_value'				=> $meta_value,
				'meta_compare'				=> $meta_compare,
				'orderby'					=> $orderby,
				'order'						=> $order,
			);
		
		} elseif ( $cause_type == "cause-last-miles" ) {
			$args = array(
				'posts_per_page'			=> "-1",
				'post_type'					=> 'causes',
				'post_status'				=> 'publish',
				'meta_key'					=> $meta_key,
				'meta_value'				=> $meta_value,
				'meta_compare'				=> $meta_compare,
				'orderby'					=> $orderby,
				'order'						=> $order,
			);
		
		} else {
			$args = array(
				'posts_per_page'			=> "-1",
				'post_type'					=> 'causes',
				'post_status'				=> 'publish',
				'orderby'					=> $orderby,
				'order'						=> $order,
			);
		
		} 
		
		if ( isset($_GET['filter_category']) && $_GET['filter_category'] <> '' && $_GET['filter_category'] <> '0' ) { 
			$causes_category_array = array('causes-category' => $_GET['filter_category']);
			$args = array_merge($args, $causes_category_array);
		
		} else if(isset($cause_cat) && $cause_cat <> '' && $cause_cat <> '0'){
			$causes_category_array = array('causes-category' => "$cause_cat");
			$args = array_merge($args, $causes_category_array);
		}
            
			$custom_query = new WP_Query($args);
            $count_post = 0;
			$counter = 1;
			$count_post = $custom_query->post_count;
			
			if ( $cause_type == "upcoming_causes") {
				
				$args = array(
					'posts_per_page'			=> "$cause_per_page",
					'paged'						=> $_GET['page_id_all'],
					'post_type'					=> 'causes',
					'post_status'				=> 'publish',
					'meta_key'					=> $meta_key,
					'meta_value'				=> $meta_value,
					'meta_compare'				=> $meta_compare,
					'orderby'					=> $orderby,
					'order'						=> $order,
				 );
			} else if ( $cause_type == "past_causes" ) {
				
					$args = array(
						'posts_per_page'			=> "$cause_per_page",
						'paged'						=> $_GET['page_id_all'],
						'post_type'					=> 'causes',
						'meta_key'					=> $meta_key,
						'meta_value'				=> $meta_value,
						'meta_compare'				=> $meta_compare,
						'orderby'					=> $orderby,
						'order'						=> $order,
					);
				
			} else if ( $cause_type == "cause-succesfully" ) {
				
					$args = array(
						'posts_per_page'			=> "$cause_per_page",
						'paged'						=> $_GET['page_id_all'],
						'post_type'					=> 'causes',
						'meta_key'					=> $meta_key,
						'meta_value'				=> $meta_value,
						'meta_compare'				=> $meta_compare,
						'orderby'					=> $orderby,
						'order'						=> $order,
					);
				
			} else if ( $cause_type == "cause-last-miles" ) {
				
					$args = array(
						'posts_per_page'			=> "$cause_per_page",
						'paged'						=> $_GET['page_id_all'],
						'post_type'					=> 'causes',
						'meta_key'					=> $meta_key,
						'meta_value'				=> $meta_value,
						'meta_compare'				=> $meta_compare,
						'orderby'					=> $orderby,
						'order'						=> $order,
					);
				
			} else {
				$args = array(
                    'posts_per_page'			=> "$cause_per_page",
					'paged'						=> $_GET['page_id_all'],
                    'post_type'					=> 'causes',
                    'post_status'				=> 'publish',
                   	'meta_key'					=> $meta_key,
                    'meta_value'				=> $meta_value,
                    'meta_compare'				=> $meta_compare,
                    'orderby'					=> $orderby,
                    'order'						=> $order,
                );
			}
		
		
		
		if ( isset($_GET['filter_category']) && $_GET['filter_category'] <> '' && $_GET['filter_category'] <> '0' ) 
		{ 
			$causes_category_array = array('causes-category' => "$cause_cat");
			$args = array_merge($args, $causes_category_array);
		
		} else if(isset($cause_cat) && $cause_cat <> '' && $cause_cat <> '0'){
			$causes_category_array = array('causes-category' => "$cause_cat");
			$args = array_merge($args, $causes_category_array);
		}
		
		if(isset($filter_category) && $filter_category <> '' && $filter_category <> '0'){
				
				if ( isset($_GET['filter-tag']) ) {$filter_tag = $_GET['filter-tag'];}
				if($filter_tag <> ''){
					$causes_category_array = array('causes-category' => "$filter_category",'causes-tag' => "$filter_tag");
				}else{
					$causes_category_array = array('causes-category' => "$filter_category");
				}
				$args = array_merge($args, $causes_category_array);
			}
			
		if ( isset($_GET['filter-tag']) && $_GET['filter-tag'] <> '' && $_GET['filter-tag'] <> '0' ) {
			$filter_tag = $_GET['filter-tag'];
			if($filter_tag <> ''){
				$causes_category_array = array('causes-category' => "$filter_category",'causes-tag' => "$filter_tag");
				$args = array_merge($args, $causes_category_array);
			}
		}
		if ( isset($_GET['organizer']) && $_GET['organizer'] <> '' ) {
			$user_meta_key				= '';
			$user_meta_value			= '';
		}
		
		$user_args = array(
                    'posts_per_page'			=> "-1",
					'post_type'					=> 'causes',
					'post_status'				=> 'publish',
					'meta_key'					=> $user_meta_key,
                    'meta_value'				=> $user_meta_value,
                );
		
		$custom_query = new WP_Query($args);
		
		$user_query = new WP_Query($user_args);
		$count_post = $user_query->post_count;
		$userArray	= ''; 			
		while ( $user_query->have_posts() ) { $user_query->the_post();
			$user_id = get_post_meta($post->ID, "cause_organizer", true);			
			if (isset( $user_id ) && $user_id !='' ){
				$userArray[] = $user_id;
			}
		}
		
		
		wp_reset_postdata();
		
		cs_get_cause_filters($cause_cat,$cs_cause_filterable,$filter_category,$filter_tag,$userArray,$organizer_filter,$cs_cause_animation);
		
		if ( $custom_query->have_posts() <> "" ) {
			
			while ( $custom_query->have_posts() ): $custom_query->the_post();
			
			$width				= '844';
			$height				= '475';
			$image_url 			= cs_get_post_img_src($post->ID, $width, $height);
			$title_limit 		= 60;
			$background			= '';
			$raisedPercentage 	= 0;
			$cause_end_date 	= get_post_meta($post->ID, "cause_end_date", true);
			$goal_amount 		= get_post_meta($post->ID, "cs_cause_goal_amount", true);
			$raised_amount 		= get_post_meta($post->ID, "cs_cause_raised_amount", true);
			$raisedPercentage 	= get_post_meta($post->ID, "cs_cause_percentage_amount", true);
			$randId 			= cs_generate_random_string(5);
	?>
		
       <script type="text/javascript">
		   jQuery(document).ready(function($){
			jQuery('.skillbar-<?php echo esc_js($randId);?>').each(function($) {
				jQuery(this).waypoint(function(direction) {
					jQuery(this).find('.skillbar-bar').animate({
						width: jQuery(this).attr('data-percent')
					}, 2000);
				}, {
					offset: "100%",
					triggerOnce: true
				});
			});
		});
		
		
	   </script>
       <div class="col-md-12 <?php echo esc_attr( $cs_cause_animation );?>" <?php echo esc_attr( $CustomId );?>> 
        <article class="cs-causes causes-classic">
          <?php if ( $image_url ) { ?>
                <figure><a href="<?php the_permalink();?>"><img alt="" src="<?php echo esc_url( $image_url );?>"></a></figure>
          <?php }?>
          <section>
            <h2><a href="<?php the_permalink();?>"><?php echo substr(get_the_title(),0, $title_limit); if(strlen(get_the_title())>$title_limit){echo '...';}?></a></h2>
            <ul class="post-option">
              <li> <i class="fa fa-calendar"></i><?php echo esc_attr( date_i18n( get_option( 'date_format' ),strtotime( $cause_end_date ) ) );?></li>
              
              <li><?php cs_get_categories( $cause_cat );?></li>
            </ul>
            <?php if ( $cs_cause_description=='on' ){?><p><?php echo cs_get_the_excerpt($cs_cause_excerpt,false, 'Read More');?></p><?php }?>
            <div class="skills-sec">
              <div class="cs-progres-bar ">
                <div class="cs-amount"> 
                    <span class="raised-amount">
                        <?php echo esc_attr( $paypal_currency_sign.number_format(absint($raised_amount)) );?><?php esc_html_e(' Raised','Cause');?></span> <span class="goal-amount"><?php _e('Goal ','Cause'); echo esc_attr( $paypal_currency_sign.number_format(absint($goal_amount)) );?>
                    </span> 
                </div>
                <div class="patteren">
                  <div class="cs-skillbar">
                    <div data-percent="<?php echo esc_attr( $raisedPercentage );?>%" class="skillbar-<?php echo esc_attr($randId);?>">
                      <div class="skillbar-bar"></div>
                    </div>
                  </div>
                  <!--patteren--> 
                </div>
              </div>
              <a class="btn-style1" href="<?php the_permalink();?>"><i class="fa fa-database"></i><?php esc_html_e('Contribute Now','Cause');?></a> </div>
          </section>
          <!--causes-classic--> 
        </article>
      </div>
	  <?php 
      
         endwhile;
         $qrystr = '';
         if ( $cause_pagination == "Show Pagination" and $count_post > $cause_per_page and $cause_per_page > 0) {
                 if ( isset($_GET['organizer']) ) $qrystr .= "&amp;organizer=".$_GET['organizer'];
				 if ( isset($_GET['sort']) ) $qrystr .= "&amp;sort=".$_GET['sort'];
				 if ( isset($_GET['filter_category']) ) $qrystr .= "&amp;filter_category=".$_GET['filter_category'];
				 if ( isset($_GET['filter-tag']) ) $qrystr .= "&amp;filter-tag=".$_GET['filter-tag'];
				 if ( isset($_GET['page_id']) ) $qrystr .= "&amp;page_id=".$_GET['page_id'];
                
                 echo cs_pagination($count_post, $cause_per_page,$qrystr);
         }
	  } else {
	  	echo '<div class="col-md-12"><div class="succ_mess"><p>';
			esc_html_e('No Causes Found','Cause');
		echo '</p></div</div>';
	  }
  }

/**
* Cause Classic Shortcode
*/
function cs_get_categories( $category ) {
		global $wpdb;
	if ( $category !='' && $category !='0'){ 
		$row_cat = $wpdb->get_row($wpdb->prepare("SELECT * from $wpdb->terms WHERE slug = %s", $category ));
	}
	
	if ( isset($category) && $category !='' && $category !='0'){ 
		echo '<a href="'.site_url().'?cat='.$row_cat->term_id.'">'.$row_cat->name.'</a>';
	 } else {
		 /* Get All Tags */
		  $before_cat = '<i class="fa fa-folder-o"></i>';
		  $categories_list = get_the_term_list ( get_the_id(), 'causes-category', $before_cat , ', ', '' );
		  if ( $categories_list ){
			printf( __( '%1$s', 'Cause'),$categories_list );
		  } 
		 // End if Tags 
	 }
 }
		 	
}

/**
* Cause Listing Shortcode
*/ 
if (!function_exists('cs_latest_causes_shortcode')) {
	function cs_latest_causes_shortcode( $atts ) {
		global $post,$wpdb;
		$defaults = array( 'latest_cause_title' => '', 'latest_cause_cat' => '','latest_cause_button_aling' => '','latest_cause_text_color' => '','cs_latest_cause_class' => '','cs_latest_cause_animation' => '');
		extract( shortcode_atts( $defaults, $atts ) );
		$textColor	= '';
		$CustomId	= '';
		if ( isset( $cs_cause_class ) && $cs_cause_class ) {
			$CustomId	= 'id="'.$cs_cause_class.'"';
		}
		
		if ( trim($cs_latest_cause_animation) !='' ) {
			$cs_cause_animation	= 'wow'.' '.$cs_latest_cause_animation;
		} else {
			$cs_cause_animation	= '';
		}
		
		if ( isset ( $latest_cause_text_color ) && $latest_cause_text_color !='' ){
			$textColor	= 'style=color:'.$latest_cause_text_color.';';
		}
		
		
		$args = array('posts_per_page' => "1", 'post_type' => 'causes','order' => 'DESC', 'post_status' => 'publish');
		
		if(isset($latest_cause_cat) && $latest_cause_cat <> '' && $latest_cause_cat <> '0'){
			$causes_category_array = array('causes-category' => "$latest_cause_cat");
			$args = array_merge($args, $causes_category_array);
		}
		
		$paypal_currency_sign = isset($cs_theme_options['paypal_currency_sign'])?$cs_theme_options['paypal_currency_sign']:'$';
		
		$section_title = '';
		if(isset($latest_cause_title) && trim($latest_cause_title) <> ''){
			$section_title = '<div class="cs-section-title"><h2>'.$latest_cause_title.'</h2></div>';
		}
		$custom_query = new WP_Query($args);
		
		$post_count = $custom_query->post_count;
		wp_reset_postdata();
		
		if ( $custom_query->have_posts() <> "" ) {
			
			while ( $custom_query->have_posts() ): $custom_query->the_post();
			
			
			$goal_amount 		= get_post_meta($post->ID, "cs_cause_goal_amount", true);
			$raised_amount 		= get_post_meta($post->ID, "cs_cause_raised_amount", true);
			$raisedPercentage 	= get_post_meta($post->ID, "cs_cause_percentage_amount", true);
			$randId 			= cs_generate_random_string(5);
		?>
		<script type="text/javascript">
		   jQuery(document).ready(function($){
			jQuery('.skillbar-<?php echo esc_js($randId);?>').each(function($) {
				jQuery(this).waypoint(function(direction) {
					jQuery(this).find('.skillbar-bar').animate({
						width: jQuery(this).attr('data-percent')
					}, 2000);
				}, {
					offset: "100%",
					triggerOnce: true
				});
			});
		});
	   </script>
        <div class="col-md-12 post-<?php echo intval( $post->ID );?> <?php echo esc_attr( $cs_cause_animation );?>" <?php echo esc_attr( $CustomId );?>> 
        <?php echo balanceTags( $section_title );?>
        <!-- Article -->
        <article class="cs-causes latest-causes has_shapes <?php echo esc_attr( $latest_cause_button_aling );?>">
          <section>
            <div class="skills-sec">
              <div class="cs-progres-bar">
                <div class="cs-amount"><span class="raised-amount" <?php echo esc_attr( $textColor );?>><?php echo esc_attr( $paypal_currency_sign.number_format(absint($raised_amount)) );?><?php esc_html_e(' Raised','Cause');?></span> <span class="goal-amount" <?php echo esc_attr( $textColor );?>><?php _e('Goal ','Cause'); echo esc_attr( $paypal_currency_sign.number_format(absint($goal_amount)) );?></span></div>
                <div class="patteren">
                  <div class="cs-skillbar">
                    <div data-percent="<?php echo esc_attr( $raisedPercentage );?>%" class="skillbar-<?php echo esc_attr($randId);?>">
                      <div class="skillbar-bar"></div>
                    </div>
                  </div>
                  <!--patteren--> 
                </div>
              </div>
              <a class="btn-style1" href="<?php the_permalink();?>"><i class="fa fa-database"></i><?php esc_html_e('Contribute Now','Cause');?></a> </div>
          </section>
        </article>
        <!-- Article Close --> 
        </div>
		<?php
			endwhile;
		} else {?>
        	<div class="succ_mess"><p><?php esc_html_e('No Latest Cause Found.','Cause');?></p></div>
	<?php } ?>
		
	<?php }
	add_shortcode('cs_latest_cause', 'cs_latest_causes_shortcode');
}