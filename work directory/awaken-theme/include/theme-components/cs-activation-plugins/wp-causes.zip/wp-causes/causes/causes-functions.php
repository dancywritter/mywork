<?php
/**
 * @Page Builder Cause Form html
 */
if ( ! function_exists( 'cs_pb_cause' ) ) {
	function cs_pb_cause($die = 0){
		global $cs_node, $post;
		$shortcode_element = '';
		$filter_element = 'filterdrag';
		$shortcode_view = '';
		$output = array();
		$counter = $_POST['counter'];
		$cs_counter = $_POST['counter'];
		if ( isset($_POST['action']) && !isset($_POST['shortcode_element_id']) ) {
			$POSTID = '';
			$shortcode_element_id = '';
		} else {
			$POSTID = $_POST['POSTID'];
			$shortcode_element_id = $_POST['shortcode_element_id'];
			$shortcode_str = stripslashes ($shortcode_element_id);
			$PREFIX = 'cs_cause';
			$parseObject 	= new ShortcodeParse();
			$output = $parseObject->cs_shortcodes( $output, $shortcode_str , true , $PREFIX );
		}
		$defaults = array( 'cause_title' => '', 'cause_cat' => '','cause_view' => '','cause_type' => '','cs_cause_last_miles_percentage' => '','cause_pagination'=>'','cs_cause_excerpt' => '','cs_cause_description' => '','cs_cause_filterable' => '','cause_per_page' => '','cs_cause_class' => '','cs_cause_animation' => '');
		if(isset($output['0']['atts']))
			$atts = $output['0']['atts'];
		else 
			$atts = array();
		$cause_element_size = '50';
		foreach($defaults as $key=>$values){
			if(isset($atts[$key]))
				$$key = $atts[$key];
			else 
				$$key =$values;
		 }
		$name = 'cs_pb_cause';
		$coloumn_class = 'column_'.$cause_element_size;
		if(isset($_POST['shortcode_element']) && $_POST['shortcode_element'] == 'shortcode'){
			$shortcode_element = 'shortcode_element_class';
			$shortcode_view = 'cs-pbwp-shortcode';
			$filter_element = 'ajax-drag';
			$coloumn_class = '';
		}
		//
	?>
    <div id="<?php echo esc_attr($name.$cs_counter)?>_del" class="column  parentdelete <?php echo esc_attr($coloumn_class);?> <?php echo esc_attr($shortcode_view);?>" item="cause" data="<?php echo element_size_data_array_index($cause_element_size)?>" >
      <?php cs_element_setting($name,$cs_counter,$cause_element_size,'','graduation-cap');?>
      <div class="cs-wrapp-class-<?php echo esc_attr($cs_counter)?> <?php echo esc_attr($shortcode_element);?>" id="<?php echo esc_attr($name.$cs_counter)?>" data-shortcode-template="[cs_cause {{attributes}}]"  style="display: none;">
        <div class="cs-heading-area">
          <h5>Edit Cause Options</h5>
          <a href="javascript:removeoverlay('<?php echo esc_js($name.$cs_counter)?>','<?php echo esc_js($filter_element);?>')" class="cs-btnclose"><i class="fa fa-times"></i></a> </div>
        <div class="cs-pbwp-content">
          <div class="cs-wrapp-clone cs-shortcode-wrapp">
            <?php if(isset($_POST['shortcode_element']) && $_POST['shortcode_element'] == 'shortcode'){cs_shortcode_element_size();}?>
            <ul class="form-elements">
                    <li class="to-label"><label>Cause Title</label></li>
                    <li class="to-field">
                        <input type="text" name="cause_title[]" class="txtfield" value="<?php echo htmlspecialchars($cause_title)?>" />
                        <p>Cause Section Title</p>
                    </li>                                            
                </ul>
                <ul class="form-elements">
                    <li class="to-label"><label>Choose Category</label></li>
                     <li class="to-field select-style">
                        <select name="cause_cat[]" class="dropdown">
                        	<option value="">-- All Categories Posts --</option>
                             <?php show_all_cats('', '', $cause_cat, "causes-category");?>
                        </select>
                    </li>
                </ul>
			<ul class="form-elements">
                    <li class="to-label"><label>Select View</label></li>
                    <li class="to-field select-style">
                        <select name="cause_view[]" class="dropdown">
                        	<option <?php if($cause_view=="classic")echo "selected";?> value="classic">Classic</option>
                         	<option <?php if($cause_view=="medium")echo "selected";?> value="medium">Medium</option>
                         	<option <?php if($cause_view=="grid")echo "selected";?> value="grid">Grid</option>
                        </select>
                    </li>                                        
                </ul>
                <ul class="form-elements">
                        <li class="to-label"><label>Cause Types</label></li>
                        <li class="to-field select-style">
                            <select name="cause_type[]" class="dropdown" onchange="cs_toggle_cause_last_miles(this.value, '<?php echo esc_attr($cs_counter);?>')">
                                <option <?php if($cause_type=="all")echo "selected";?> value="all" >All</option>
                                <option <?php if($cause_type=="upcoming_causes")echo "selected";?> value="upcoming_causes" >Upcoming Causes</option>
                                <option <?php if($cause_type=="past_causes")echo "selected";?> value="past_causes" >Past Causes</option>
                                <option <?php if($cause_type=="cause-succesfully")echo "selected";?> value="cause-succesfully" >Successfully Funded</option>
                                
                                <option value="cause-last-miles" <?php if($cause_type == 'cause-last-miles'){echo 'selected="selected"'; }?>>Last Miles</option>
                            </select>
                        </li>
                    </ul>
                <div id="port_last<?php echo esc_attr($cs_counter)?>" <?php if($cause_type<>"cause-last-miles")echo 'style=" display:none"'?> >
                    <ul class="form-elements  noborder">
                        <li class="to-label"><label>Percentage for last miles</label></li>
                        <li class="to-field">
                            <input type="text" name="cs_cause_last_miles_percentage[]" class="txtfield" value="<?php echo (int)$cs_cause_last_miles_percentage; ?>" />
                        </li>
                    </ul>
                </div>
                <ul class="form-elements">
                  <li class="to-label">
                    <label>Filterable</label>
                  </li>
                  <li class="to-field select-style">
                    <select name="cs_cause_filterable[]" class="dropdown">
                      <option <?php if($cs_cause_filterable=="Yes")echo "selected";?> value="Yes">Yes</option>
                      <option <?php if($cs_cause_filterable=="No")echo "selected";?> value="No" >No</option>
                    </select>
                  </li>
                </ul>
                <ul class="form-elements">
                  <li class="to-label">
                    <label>Description</label>
                  </li>
                  <li class="to-field select-style">
                    <select name="cs_cause_description[]" class="dropdown">
                      <option <?php if($cs_cause_description=="on")echo "selected";?> value="on">ON</option>
                      <option <?php if($cs_cause_description=="off")echo "selected";?> value="off" >OFF</option>
                    </select>
                  </li>
                </ul>
                <div id="port_pagination<?php echo esc_attr($name.$cs_counter);?>">
                    <ul class="form-elements">
                        <li class="to-label"><label>Pagination</label></li>
                         <li class="to-field select-style">
                            <select name="cause_pagination[]" class="dropdown">
                                <option <?php if($cause_pagination=="Show Pagination")echo "selected";?> >Show Pagination</option>
                                <option <?php if($cause_pagination=="Single Page")echo "selected";?> >Single Page</option>
                            </select>
                        </li>
                    </ul>
                </div>
                <ul class="form-elements">
                    <li class="to-label"><label>Length of Excerpt</label></li>
                    <li class="to-field">
                        <input type="text" name="cs_cause_excerpt[]" class="txtfield" value="<?php echo esc_attr($cs_cause_excerpt); ?>" />
                    </li>
                </ul>
				<ul class="form-elements">
                        <li class="to-label"><label>No. of record Per Page</label></li>
                        <li class="to-field">
                            <input type="text" name="cause_per_page[]" class="txtfield" value="<?php echo esc_attr($cause_per_page); ?>" />
                            <p>To display all the records, leave this field blank.</p>
                        </li>
                    </ul>
            <?php 
			
                if ( function_exists( 'cs_shortcode_custom_dynamic_classes' ) ) {
                    cs_shortcode_custom_dynamic_classes($cs_cause_class,$cs_cause_animation,'','cs_cause');
                }
            ?>
            <?php if(isset($_POST['shortcode_element']) && $_POST['shortcode_element'] == 'shortcode'){?>
                    <ul class="form-elements" style=" background-color: #fcfcfc; margin-top: -15px; padding-top: 12px; ">
                      <li class="to-field"> <a class="insert-btn cs-main-btn" onclick="javascript:Shortcode_tab_insert_editor('<?php echo str_replace('cs_pb_','',$name);?>','<?php echo esc_attr($name.$cs_counter)?>','<?php echo esc_attr($filter_element);?>')" >Insert</a> </li>
                    </ul>
                    <div id="results-shortocde"></div>
             <?php } else {?>
                    <ul class="form-elements noborder">
                      <li class="to-label"></li>
                      <li class="to-field">
                        <input type="hidden" name="cs_orderby[]" value="cause" />
                        <input type="button" value="Save" style="margin-right:10px;" onclick="javascript:_removerlay(jQuery(this))" />
                      </li>
                    </ul>
            <?php }?>
          </div>
        </div>
      </div>
    </div>
<?php
		if ( $die <> 1 ) die();
	}
	add_action('wp_ajax_cs_pb_cause', 'cs_pb_cause');
}
/**
 * @
 */
 if ( ! function_exists( 'cs_stripslashes_htmlspecialchars' ) ) {
	function cs_stripslashes_htmlspecialchars($value){
		$value = is_array($value) ? array_map('cs_stripslashes_htmlspecialchars', $value) : stripslashes(htmlspecialchars($value));
		return $value;
	}
}

// add to wishlist
if ( ! function_exists( 'cs_addto_usermeta' ) ) :
	function cs_addto_usermeta() {
		$user = cs_get_user_id();
		if(isset($user) && $user <> ''){
			if(isset($_POST['post_id']) && $_POST['post_id'] <> ''){
				$cs_wishlist = array();
				$cs_wishlist =  get_user_meta(cs_get_user_id(),'cs-cause-wishlist', true);
					$cs_wishlist[] = $_POST['post_id'];
					$cs_wishlist = array_unique($cs_wishlist);
					update_user_meta(cs_get_user_id(),'cs-cause-wishlist',$cs_wishlist);
					$user_watchlist = get_user_meta(cs_get_user_id(),'cs-cause-wishlist', true);
						echo '<i class="fa fa-plus cs-bgcolr"></i>'.count($user_watchlist).' cause(s)in Favourite';
						
				}
		} else {
			_e('You have to login first.','Cause');
		}
		die();
	}
endif;

add_action("wp_ajax_cs_addto_usermeta", "cs_addto_usermeta");
add_action("wp_ajax_nopriv_cs_addto_usermeta", "cs_addto_usermeta");

if ( ! function_exists( 'cs_get_cause_likes' ) ) :
	function cs_get_cause_likes(){
		global $post;
		$counter = 0;
		$blogusers = get_users('orderby=nicename');
		 foreach ($blogusers as $user) {
			 $cs_wishlist =  get_user_meta($user->ID,'cs-cause-wishlist', true);
			 if(isset($cs_wishlist) && isset($post->ID) && is_array($cs_wishlist) && in_array($post->ID, $cs_wishlist)){
				 $counter++;
			 }
		 }
		 return $counter;
	}
endif;



// Delete From Wishlist
function cs_delete_wishlist(){
	if(isset($_POST['post_id']) && $_POST['post_id'] <> ''){
			$cs_wishlist = cs_get_user_meta();
			$post_id = array();
			$post_id[] = $_POST['post_id'];
			$cs_wishlist = array_diff($cs_wishlist,$post_id);
			cs_update_user_meta($cs_wishlist);
			  _e('Removed From Wishlist','Cause'); 
	} else {
		  _e('You are not authorised','Cause'); 
	}
	
	die();
	
}
add_action("wp_ajax_cs_delete_wishlist", "cs_delete_wishlist");
add_action("wp_ajax_nopriv_cs_delete_wishlist", "cs_delete_wishlist");

// get user meta
if ( ! function_exists( 'cs_get_user_meta' ) ) :
	function cs_get_user_meta($user = "") {
		if (!empty($user)){
			$userdata = get_user_by( 'login', $user );
			$user_id = $userdata->ID;
			return get_user_meta($user_id,'cs-cause-wishlist', true);
		}else{  
			 return get_user_meta(cs_get_user_id(),'cs-cause-wishlist', true);
		}
	}
endif;

// update user meta
if ( ! function_exists( 'cs_update_user_meta' ) ) :
function cs_update_user_meta($arr) {
    return update_user_meta(cs_get_user_id(),'cs-cause-wishlist',$arr);
}
endif;
// Paypal Button
if(!function_exists('cs_donate_button')){
	function cs_donate_button($cause_paypal_email = ''){
		global $post, $cs_theme_options;
		$user_id = cs_get_user_id();
		$paypal_form_flag = 1;
		if(isset($cs_theme_options['cs_donation_user_register']) && $cs_theme_options['cs_donation_user_register'] == 'on'){
			$cs_donation_user_register = $cs_theme_options['cs_donation_user_register'];
			if(empty($user_id) || !isset($user_id))
				$paypal_form_flag = 0;
		}
		if(isset($cause_paypal_email) && $cause_paypal_email <> ''){
			$cs_cause_paypal_email = $cause_paypal_email;
		} else {
			$cs_cause_paypal_email = $cs_theme_options['paypal_email'];
		}
		$cause_id = '';
		$post_type = get_post_type($post->ID);
		if($post_type == 'causes'){
			$cause_id = $post->ID;
		}
		if(isset($cs_theme_options['cs_paypal_sandbox']) && $cs_theme_options['cs_paypal_sandbox'] == 'on'){
			define("USE_SANDBOX", 1);
		} else {
			define("USE_SANDBOX", 0);
		}
		if(USE_SANDBOX == true) {
			$paypal_url = "https://www.sandbox.paypal.com/cgi-bin/webscr";
		} else {
			$paypal_url = "https://www.paypal.com/cgi-bin/webscr";
		}
		$cause_donate = __('Donate Now','Cause');
		?>
			<div class="modal fade cs-donation-form" id="CausemyModal2<?php echo absint($cause_id);?>" tabindex="-1" role="dialog">
			  <div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button aria-hidden="true" data-dismiss="modal" class="close" type="button"><i class="fa fa-times-circle"></i> </button>
						<i class="fa fa-money"></i>
						<h2><?php echo esc_attr($cause_donate);?></h2>
					</div>
					<?php 
					if($paypal_form_flag == true){
					?>
					<div class="modal-body">
					
						<h4><?php _e('Donation via paypal from your visitors','Cause');?></h4>
						
						<ul>
						   <?php 
							if(isset($cs_theme_options['paypal_payments']) && $cs_theme_options['paypal_payments'] <> ''){
								$paypal_payments = $cs_theme_options['paypal_payments'];
								$paypal_payments = explode(',',$cs_theme_options['paypal_payments']);
							} else {
								$paypal_payments = array('50','100','200','500','1000');
							}
							foreach($paypal_payments as $paypal_payments_value){
							?>
								<li><label class="cs-bgcolrhvr"><?php echo esc_attr($cs_theme_options['paypal_currency_sign'].$paypal_payments_value);?> <input type="radio" name="donate" value="<?php echo trim($paypal_payments_value);?>"></label></li>
							<?php 
							}
							?>
						</ul>
						<script>
						jQuery(document).ready(function($) {
							jQuery(".cs-donation-form ul li label") .click(function(event) {
								/* Act on the event */
								var a = jQuery(this).text().substring(1);
								  jQuery(".cs-donation-form .modal-footer label .cause-amount") .val(a)
								 jQuery(".cs-donation-form ul li label").removeClass("cs-active");
								 jQuery(this).addClass('cs-active');
								 return false;
							});
						});
						</script>
						<div class="other-options">
							<span class="opt-or"><?php _e('Or','Cause');?></span>
						</div>
					</div>
					<?php 
					}
					?>
					<div class="modal-footer">
						<?php 
						if($paypal_form_flag == true){
							$paypal_content_button = '<form action="'.$paypal_url.'" method="post">  
								<input type="hidden" name="cmd" value="_xclick">  
								<input type="hidden" name="business" value="'.$cs_cause_paypal_email.'">
								<label><span>'.$cs_theme_options['paypal_currency_sign'].'</span><input type="text" class="cause-amount" name="amount"></label> 
								<input type="hidden" name="item_name" value="'.get_the_title().'"> 
								<input type="hidden" name="no_shipping" value="2">
								<input type="hidden" name="item_number" value="'.$post->ID.'">  
								<input name = "cancel_return" value = "'.get_permalink($post->ID).'" type = "hidden">  
								<input type="hidden" name="no_note" value="1">  
								<input type="hidden" name="currency_code" value="'.$cs_theme_options['paypal_currency'].'">  
								<input type="hidden" name="notify_url" value="'.$cs_theme_options['paypal_ipn_url'].'">
								<input type="hidden" name="lc" value="AU">
								<input type="hidden" name="custom" value="'.$user_id.'">  
								<input type="hidden" name="return" value="'.get_permalink($post->ID).'">  
								<span class="donate-btn btn"><input class="bgcolr" type="submit" value="'.$cause_donate.'"> </span>
							</form> ';
							echo balanceTags($paypal_content_button, false);
						} else {
							$cause_permalink = get_permalink($post->ID);
							echo '<h4>';
							echo __('You need to login for this Donation. ','Cause');
							echo '<a href="'. wp_login_url( $cause_permalink ).'" title="Login" class="custom-btn circle cs-bg-color">'.__('Login','Cause').'</a><br /><br />';
							echo '</h4>';
						}
						?>
					</div>
				</div>
			  </div>
		</div>
	<?php
	}
}

if(!function_exists('cs_custom_donate_button')){
	function cs_custom_donate_button($cause_paypal_email = ''){
		global $post, $cs_theme_option;
		$cause_id = '';
		$cs_cause_slug = $cs_theme_options['header_support_button_url3'];
		$user_id = cs_get_user_id();
		if(!empty($cs_cause_slug)){
			// slider slug to id start
			$args=array(
			  'name' => (string)$cs_cause_slug,
			  'post_type' => 'cs_cause',
			  'post_status' => 'publish',
			  'showposts' => 1,
			);
			$get_posts = get_posts($args);
			if($get_posts){
				$cause_id = (int)$get_posts[0]->ID;
			}
		}
		if(isset($cause_paypal_email) && $cause_paypal_email <> ''){
			$cs_cause_paypal_email = $cause_paypal_email;
		} else {
			$cs_cause_paypal_email = $cs_theme_options['paypal_email'];
		}
		define("USE_SANDBOX", 0);
		if(isset($cs_theme_options['cs_paypal_sandbox']) && $cs_theme_options['cs_paypal_sandbox'] == 'on'){
			define("USE_SANDBOX", 1);
		} else {
			define("USE_SANDBOX", 0);
		}
		if(USE_SANDBOX == true) {
			$paypal_url = "https://www.sandbox.paypal.com/cgi-bin/webscr";
		} else {
			$paypal_url = "https://www.paypal.com/cgi-bin/webscr";
		}
		
		$cause_donate = __('Donate Now','Cause');
		?>
			<div class="modal fade cs-donation-form" id="myModal2" tabindex="-1" role="dialog">
			  <div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button aria-hidden="true" data-dismiss="modal" class="close" type="button"><i class="fa fa-times-circle"></i></button>
						<i class="fa fa-money"></i>
						<h2><?php _e('Make Donations','Cause'); ?></h2>
					</div>
					<div class="modal-body">
						<h4><?php _e('Donation via paypal from your visitors','Cause');?></h4>
					</div>
					<div class="modal-footer">
						<?php 
							$paypal_content_button = '<form action="'.$paypal_url.'" method="post">  
	
								<input type="hidden" name="cmd" value="_xclick">  
						
								<input type="hidden" name="business" value="'.$cs_cause_paypal_email.'">
						
								<label><span>'.$cs_theme_options['paypal_currency_sign'].'</span><input type="text" class="cause-amount" name="amount"></label> 
						
								<input type="hidden" name="item_name" value="'.get_the_title($cause_id).'"> 
						
								<input type="hidden" name="no_shipping" value="2">
						
								<input type="hidden" name="item_number" value="'.$cause_id.'">  
						
								<input name = "cancel_return" value = "'.get_permalink($cause_id).'" type = "hidden">  
						
								<input type="hidden" name="no_note" value="1">  
						
								<input type="hidden" name="currency_code" value="'.$cs_theme_options['paypal_currency'].'">  
						
								<input type="hidden" name="notify_url" value="'.$cs_theme_options['paypal_ipn_url'].'">
						
								<input type="hidden" name="lc" value="AU">
								
								<input type="hidden" name="custom" value="'.$user_id.'">  
						
								<input type="hidden" name="return" value="'.get_permalink($cause_id).'">  
						
								<span class="donate-btn btn"><input class="bgcolr" type="submit" value="'.$cause_donate.'"> </span>
						
							</form> ';
							echo balanceTags($paypal_content_button, false);
						?>
					</div>
				</div>
			  </div>
		</div>
	<?php
	}
}

//
if(!function_exists('cs_validate')){
	function cs_validate($value){
		return $value;
	}
}

/**
 * @Page Builder Cause Form html
 */
if ( ! function_exists( 'cs_pb_latest_cause' ) ) {
	function cs_pb_latest_cause($die = 0){
		
		global $cs_node, $post;
		$shortcode_element = '';
		$filter_element = 'filterdrag';
		$shortcode_view = '';
		$output = array();
		$counter = $_POST['counter'];
		$cs_counter = $_POST['counter'];
		if ( isset($_POST['action']) && !isset($_POST['shortcode_element_id']) ) {
			$POSTID = '';
			$shortcode_element_id = '';
		} else {
			$POSTID = $_POST['POSTID'];
			$shortcode_element_id = $_POST['shortcode_element_id'];
			$shortcode_str = stripslashes ($shortcode_element_id);
			$PREFIX = 'cs_latest_cause';
			$parseObject 	= new ShortcodeParse();
			$output = $parseObject->cs_shortcodes( $output, $shortcode_str , true , $PREFIX );
		}
		$defaults = array( 'latest_cause_title' => '', 'latest_cause_cat' => '','latest_cause_button_aling' => '','latest_cause_text_color' => '','cs_latest_cause_class' => '','cs_latest_cause_animation' => '');
		if(isset($output['0']['atts']))
			$atts = $output['0']['atts'];
		else 
			$atts = array();
		$latest_cause_element_size = '50';
		foreach($defaults as $key=>$values){
			if(isset($atts[$key]))
				$$key = $atts[$key];
			else 
				$$key =$values;
		 }
		$name = 'cs_pb_latest_cause';
		$coloumn_class = 'column_'.$latest_cause_element_size;
		if(isset($_POST['shortcode_element']) && $_POST['shortcode_element'] == 'shortcode'){
			$shortcode_element = 'shortcode_element_class';
			$shortcode_view = 'cs-pbwp-shortcode';
			$filter_element = 'ajax-drag';
			$coloumn_class = '';
		}
		
		//
	?>
    <div id="<?php echo esc_attr($name.$cs_counter)?>_del" class="column  parentdelete <?php echo esc_attr($coloumn_class);?> <?php echo esc_attr($shortcode_view);?>" item="cause" data="<?php echo element_size_data_array_index($latest_cause_element_size)?>" >
      <?php cs_element_setting($name,$cs_counter,$latest_cause_element_size,'','graduation-cap');?>
      <div class="cs-wrapp-class-<?php echo esc_attr($cs_counter)?> <?php echo esc_attr($shortcode_element);?>" id="<?php echo esc_attr($name.$cs_counter)?>" data-shortcode-template="[cs_latest_cause {{attributes}}]"  style="display: none;">
        <div class="cs-heading-area">
          <h5>Edit Latest Cause Options</h5>
          <a href="javascript:removeoverlay('<?php echo esc_js($name.$cs_counter)?>','<?php echo esc_js($filter_element);?>')" class="cs-btnclose"><i class="fa fa-times"></i></a> </div>
        <div class="cs-pbwp-content">
          <div class="cs-wrapp-clone cs-shortcode-wrapp">
            <?php if(isset($_POST['shortcode_element']) && $_POST['shortcode_element'] == 'shortcode'){cs_shortcode_element_size();}?>
            <ul class="form-elements">
                    <li class="to-label"><label>Section Title</label></li>
                    <li class="to-field">
                        <input type="text" name="latest_cause_title[]" class="txtfield" value="<?php echo htmlspecialchars($latest_cause_title)?>" />
                        <p>Section Title</p>
                    </li>                                            
                </ul>
                <ul class="form-elements">
                    <li class="to-label"><label>Choose Category</label></li>
                    <li class="to-field">
                        <select name="latest_cause_cat[]" class="dropdown">
                        	<option value="">-- All Categories Posts --</option>
                             <?php show_all_cats('', '', $latest_cause_cat, "causes-category");?>
                        </select>
                    </li>
                </ul>
			<ul class="form-elements">
                <li class="to-label"><label>Button Align</label></li>
                <li class="to-field">
                    <select name="latest_cause_button_aling[]" class="dropdown">
                        <option <?php if($latest_cause_button_aling=="left")echo "selected";?> value="left">Left</option>
                        <option <?php if($latest_cause_button_aling=="right")echo "selected";?> value="right">Right</option>
                        <option <?php if($latest_cause_button_aling=="center")echo "selected";?> value="center">Center</option>
                    </select>
                </li>                                        
            </ul>
            <ul class="form-elements">
              <li class="to-label">
                <label>Text Color</label>
              </li>
              <li class="to-field">
                <input type="text" name="latest_cause_text_color[]" class="bg_color"  value="<?php echo esc_attr($latest_cause_text_color);?>" />
              </li>
            </ul>    
            <?php 
                if ( function_exists( 'cs_shortcode_custom_dynamic_classes' ) ) {
                    cs_shortcode_custom_dynamic_classes($cs_latest_cause_class,$cs_latest_cause_animation,'','cs_latest_cause');
                }
             	if(isset($_POST['shortcode_element']) && $_POST['shortcode_element'] == 'shortcode'){?>
                    <ul class="form-elements" style=" background-color: #fcfcfc; margin-top: -15px; padding-top: 12px; ">
                      <li class="to-field"> <a class="insert-btn cs-main-btn" onclick="javascript:Shortcode_tab_insert_editor('<?php echo str_replace('cs_pb_','',$name);?>','<?php echo esc_js($name.$cs_counter)?>','<?php echo esc_js($filter_element);?>')" >Insert</a> </li>
                    </ul>
                    <div id="results-shortocde"></div>
             <?php } else {?>
                    <ul class="form-elements noborder">
                      <li class="to-label"></li>
                      <li class="to-field">
                        <input type="hidden" name="cs_orderby[]" value="latest_cause" />
                        <input type="button" value="Save" style="margin-right:10px;" onclick="javascript:_removerlay(jQuery(this))" />
                      </li>
                    </ul>
            <?php }?>
          </div>
        </div>
      </div>
    </div>
<?php
		if ( $die <> 1 ) die();
	}
	add_action('wp_ajax_cs_pb_latest_cause', 'cs_pb_latest_cause');
}
if ( ! function_exists( 'cs_delete_compaign_thumbnail' ) ) {
	function cs_delete_compaign_thumbnail(){
		$post_id = $_POST['post_id'];
		$thumb_id = $_POST['thumb_id'];
		if ( current_user_can('edit_posts',$post_id ) ) {
			update_post_meta($post_id,'_thumbnail_id','');
		}
		if ( current_user_can('delete_posts') ) {
			$delte = wp_delete_attachment( $thumb_id );
			if($delte)
				echo 'Attachment Removed';
		}
		die();
	}
	add_action('wp_ajax_cs_delete_compaign_thumbnail', 'cs_delete_compaign_thumbnail');
}


//=====================================================================
// Cause filtering methods
//=====================================================================
function cs_get_cause_filters($cs_filter_category,$cs_filter_switch,$filter_category,$filter_tag,$userArray,$organizer_filter,$cs_custom_animation){
	 global $post,$cs_theme_options,$cs_counter_node,$wpdb;
	 $nav_count = rand(40, 9999999);
	 if ( isset( $cs_filter_switch ) && $cs_filter_switch == 'Yes') { 
	 ?>
		<!--Sorting Navigation-->
        <div class="col-md-12">
          <nav class="wow filter-nav <?php echo esc_attr($cs_custom_animation);?>">
            <ul class="cs-filter-menu pull-left">
              <li> <a href="#pager-1<?php echo esc_attr($nav_count);?>"> <i class="fa fa-search"></i><?php 
               _e('Filter By','Awaken'); ?>  
               </a> </li>
              <li><a href="#pager-2<?php echo esc_attr($nav_count);?>"><i class="fa fa-list"></i><?php 
                   _e('Categories','Awaken');  
              ?></a></li>
              <li><a href="#pager-3<?php echo esc_attr($nav_count);?>"><i class="fa fa-tags"></i><?php 
                 _e('Tags','Awaken'); 
              ?></a></li>
              <li><a href="#pager-4<?php echo esc_attr($nav_count);?>"><i class="fa fa-user"></i><?php 
                 _e('Organizers','Awaken'); 
              ?></a></li>
            </ul>
            <a href="<?php the_permalink();?>" class="pull-right cs-btnshowall"> <i class="fa fa-check-circle-o"></i>
                <?php   _e('Show All','Awaken'); ?>  
            </a>
            <div id="pager-1<?php echo esc_attr($nav_count);?>" class="filter-pager" style="display: none;"> <a class="<?php if(isset($_GET['sort']) and $_GET['sort']=='asc') { echo 'active';}?>" href="?<?php echo 'organizer='.$organizer_filter.'&amp;sort=asc&amp;filter_category='.$filter_category.'&amp;filter-tag='.$filter_tag; ?>"> <?php    _e('Date Published','Awaken'); ?> </a> <a class="<?php if(isset($_GET['sort']) and $_GET['sort']=='alphabetical') { echo 'active';}?>" href="?<?php echo 'organizer='.$organizer_filter.'&amp;sort=alphabetical&amp;filter_category='.$filter_category.'&amp;filter_tag='.$filter_tag; ?>"> <?php echo _e('Alphabetical','Awaken');?></a></div>
            <div id="pager-2<?php echo esc_attr($nav_count);?>" class="filter-pager" style="display: none;">
              <?php
                $row_cat = $wpdb->get_row($wpdb->prepare("SELECT * from $wpdb->terms WHERE slug = %s", $cs_filter_category ));
                if( isset($cs_filter_category) && ($cs_filter_category <> "" && $cs_filter_category <> "0")   && isset( $row_cat->term_id )){	
                  $categories = get_categories( array('child_of' => "$row_cat->term_id", 'taxonomy' => 'causes-category', 'hide_empty' => 0));
                ?>
              <a href="?<?php echo "organizer=".$organizer_filter."&amp;filter_category=".$filter_category; ?>"class="<?php if(($cs_filter_category == $filter_category)){ echo 'bgcolr';}?>"><?php  _e('All Categories','Awaken'); ?></a>
              <?php
                }else{
                    $categories = get_categories( array('taxonomy' => 'causes-category', 'hide_empty' => 0) );
                }
                foreach ($categories as $category) {
                ?>
              <a href="?<?php echo "organizer=".$organizer_filter."&amp;filter_category=".$category->slug?>" 
                          <?php if($category->slug==$filter_category){echo 'class="active"';}?>> <?php echo esc_attr($category->cat_name); ?> </a>
              <?php }?>
            </div>
            <div id="pager-3<?php echo esc_attr($nav_count);?>" class="filter-pager" style="display: none;">
              <?php cs_get_cause_tags_list ($filter_category,$filter_tag,$organizer_filter); ?>
            </div>
            <div id="pager-4<?php echo esc_attr($nav_count);?>" class="filter-pager" style="display: none;">
              <?php 
                $eventusers = get_users('orderby=nicename');
                if ( isset( $userArray ) && $userArray !='' && is_array( $userArray ) ) {
                    foreach ($eventusers as $user) {
                        if ( in_array( $user->ID,$userArray )) {
                         ?>
                  <a <?php if(isset($_GET['organizer']) && $user->ID ==$_GET['organizer']){echo 'class="active"';}?> href="?<?php echo 'organizer='.$user->ID.'&amp;filter_category='.$filter_category.'&amp;filter_tag='.$filter_tag; ?>"> <?php echo esc_attr($user->display_name);?> </a>
                  <?php } }
                    } else {?>
                  <a><?php _e('No Organizer Found.','Awaken'); ?> </a>
                  <?php }?>
            </div>
          </nav>
        </div>
	<!--Sorting Navigation End-->
	<?php 
	} 		
}


//=====================================================================
// Get Cause tags list
//=====================================================================
if ( ! function_exists( 'cs_get_cause_tags_list' ) ) { 
		function cs_get_cause_tags_list($filter_category = '',$filter_tag  ='',$organizer_filter=''){
			global $post;
			$args = array('posts_per_page'=>-1,'post_type' => 'causes','causes-category' => $filter_category);
			$project_query = new WP_Query($args);
			$count_post = $project_query->post_count;
			$all_tags_arr	= array();
			while ($project_query->have_posts()) : $project_query->the_post();
				$posttags = get_the_terms($post->ID,'causes-tag');
				if ($posttags) {
					foreach($posttags as $tag) {
						$all_tags_arr[] = $tag->name; //USING JUST $tag MAKING $all_tags_arr A MULTI-DIMENSIONAL ARRAY, WHICH DOES WORK WITH array_unique
					}
				}
			endwhile;
			if ( is_array($all_tags_arr) && count($all_tags_arr) > 0 ){ 
				$tags_arr = array_unique($all_tags_arr); //REMOVES DUPLICATES
				foreach( $tags_arr as $tag ):
					$active_class = '';
					$el = get_term_by('name', $tag, 'causes-tag');
					$arr[] = '"tag-'.$el->slug.'"';
					if($filter_tag==$el->slug){
						$active_class = "class='active'";
					}
					echo '<a href="?organizer='.$organizer_filter.'&amp;?filter_category='.$filter_category.'&amp;filter-tag='.$el->slug.'" id="taglink-tag-'.$el->slug.'" title="tag-'.$el->slug.'" '.$active_class.' >'.$el->name.'</a>';
				endforeach; 
			}else{
				 _e('<a>No Tags Found.</a>','Awaken');
			}
		}
}


/**
 * @Donation widget Class
 *
 *
 */
if ( ! class_exists( 'cs_donation' ) ) { 
	class cs_donation extends WP_Widget {	
	
		/**
		 * Outputs the content of the widget
		 *
		 * @param array $args
		 * @param array $instance
		 */
			 
		/**
		 * @init Donation Module
		 *
		 *
		 */
		function cs_donation() {
			$widget_ops = array('classname' => 'cs-donation-form', 'description' => 'Donation form widget.');
			$this->WP_Widget('cs_donation', 'CS : Donation', $widget_ops);
		}
		 
		 /**
		 * @Donation html form
		 *
		 *
		 */
		function form($instance){
			$instance = wp_parse_args( (array) $instance, array( 'title' => '') );
			$title = $instance['title'];
	
		?>
		<p>
            <label for="<?php echo cs_allow_special_char($this->get_field_id('title')); ?>"> Title:
            <input class="upcoming" id="<?php echo cs_allow_special_char($this->get_field_id('title')); ?>" size="40" name="<?php echo cs_allow_special_char($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
            </label>
		</p>
      
        

		<?php
		}
			
		/**
		 * @Donation update form data
		 *
		 *
		 */
		function update($new_instance, $old_instance){
			$instance = $old_instance;
			$instance['title'] = $new_instance['title'];
						
			return $instance;
		}
	
		/**
		 * @Display Donation widget
		 *
		 *
		 */
		function widget($args, $instance){
			global $cs_theme_options, $post;
			
			extract($args, EXTR_SKIP);
			$title = empty($instance['title']) ? ' ' : apply_filters('widget_title', $instance['title']);			
			
			echo cs_allow_special_char($before_widget);	
			
			if (!empty($title) && $title <> ' '){
				echo cs_allow_special_char($before_title);
				echo cs_allow_special_char($title);
				echo cs_allow_special_char($after_title);
			}
			$cause_donate = __('Donate Now', 'Awaken');
			$other_amount = __('Other Amount', 'Awaken');
			if(isset($cs_theme_options['paypal_email']) && $cs_theme_options['paypal_email'] <> ''){
				$cs_cause_paypal_email = $cs_theme_options['paypal_email'];
			} else {
				$cs_cause_paypal_email = '';
			}
			$cs_cause_paypal_email = $cs_theme_options['paypal_email'];
			$paypal_url = "https://www.paypal.com/cgi-bin/webscr";
			$cause_donate = __('Donate Now','Cause');
			?>
            <script>
			jQuery(document).ready(function($) {
				jQuery(".cs-donation-form ul li label") .click(function(event) {
					/* Act on the event */
					var a = jQuery(this).text().substring(1);
					 jQuery(".cs-donation-form .other-amount label .cause-amount") .val(a)
					 jQuery(".cs-donation-form ul li label").removeClass("cs-active");
					 jQuery(this).addClass('cs-active');
					 return false;
				});
			});
			</script>
            <article class="donat-widget">
              <ul>
               <?php 
				if(isset($cs_theme_options['paypal_payments']) && $cs_theme_options['paypal_payments'] <> ''){
					$paypal_payments = $cs_theme_options['paypal_payments'];
					$paypal_payments = explode(',',$cs_theme_options['paypal_payments']);
				} else {
					$paypal_payments = array('50','100','200','500','1000');
				}
				$counter=1;
				foreach($paypal_payments as $paypal_payments_value){
					$li_class = '';
					if($counter==1) $li_class = ' class="cs-active"';
					?>
					<li><label<?php echo cs_allow_special_char($li_class); ?>><?php echo cs_allow_special_char($cs_theme_options['paypal_currency_sign'].$paypal_payments_value);?> <input type="radio" name="donate" value="<?php echo trim($paypal_payments_value);?>"></label></li>
					<?php 
					$counter++;
				}
				?>
              </ul>
              <div class="other-amount">
                <header>
                  <h6><?php echo cs_allow_special_char($other_amount); ?></h6>
                </header>
                
                <?php
				wp_reset_query();
				$paypal_content_button = '<form action="https://www.paypal.com/cgi-bin/webscr" method="post">  

				<input type="hidden" name="cmd" value="_xclick">  
		
				<input type="hidden" name="business" value="'.$cs_theme_options['paypal_email'].'">
		
				<label><span>'.$cs_theme_options['paypal_currency_sign'].'</span><input type="text" class="cause-amount" name="amount"></label> 
		
				<input type="hidden" name="item_name" value="'.$title.'"> 
		
				<input type="hidden" name="no_shipping" value="2">
		
				<input type="hidden" name="item_number" value="'.$post->ID.'">  
		
				<input name = "cancel_return" value = "'.get_permalink().'" type = "hidden">  
		
				<input type="hidden" name="no_note" value="1">  
				
				<input type="hidden" name="currency_code" value="'.$cs_theme_options['paypal_currency'].'">  
		
				<input type="hidden" name="notify_url" value="'.get_home_url().'">
		
				<input type="hidden" name="lc" value="AU">  
		
				<input type="hidden" name="return" value="'.get_permalink().'">  
		
				<span class="donate-btn btn"><input class="bgcolr" type="submit" value="'.$cause_donate.'"> </span>
		
				</form> ';
			
				echo cs_allow_special_char($paypal_content_button);
				?>
                
                </div>
            </article>
            <?php

			echo cs_allow_special_char($after_widget);
		}
	}
}
add_action('widgets_init', create_function('', 'return register_widget("cs_donation");'));