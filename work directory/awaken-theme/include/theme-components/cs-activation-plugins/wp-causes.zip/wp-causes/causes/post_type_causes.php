<?php
	//adding columns start
    add_filter('manage_causes_posts_columns', 'causes_columns_add');
	function causes_columns_add($columns) {
		$columns['category'] = 'Category';
		$columns['author'] = 'Author';
		return $columns;
	}
    add_action('manage_causes_posts_custom_column', 'causes_columns');
	function causes_columns($name) {
		global $post;
		switch ($name) {
			case 'category':
				$categories = get_the_terms( $post->ID, 'causes-category' );
					if($categories <> ""){
						$couter_comma = 0;
						foreach ( $categories as $category ) {
							echo esc_attr($category->name);
							$couter_comma++;
							if ( $couter_comma < count($categories) ) {
								echo ", ";
							}
						}
					}
				break;
			case 'author':
				echo get_the_author();
				break;
		}
	}
	if(!class_exists('post_type_causes')){
		/**
		 * Causes Post Type Class
		*/
		class post_type_causes
		{
			/**
			 * The Constructor
			*/
			public function __construct()
			{
				// register actions
				add_action('init', array(&$this, 'cs_causes_init'));
				$role = get_role( 'organizer' );
				if(!isset($role)){
					$role = add_role( 'organizer', 'Organizer', array(
						'read' => true, // True allows that capability
						'write' => true, // True allows that capability
						'edit_posts'   => true,
						'delete_posts' => false, // Use false to explicitly deny
					) );
				}
				add_action('admin_init', array(&$this, 'cs_cause_admin_init'));
				if ( isset($_POST['cause_meta_form']) and $_POST['cause_meta_form'] == 1 ) {
					add_action( 'save_post', array(&$this, 'cs_meta_causes_save') );  
				}
			} 
			
			/**
			 * hook into WP's init action hook
			*/
			public function cs_causes_init()
			{
				// Initialize Post Type
				$this->cs_cause_register();
				$this->cs_causes_register_categories();
				$this->cs_causes_register_tags();
			}
			
			/**
			 * Create the Cause post type
			 */
			public function cs_cause_register()
			{
				register_post_type( 'causes',	array(
									'labels'             => array(
									'name' 				 => __('Causes','Cause'),
									'all_items'			 => __('Causes','Cause'),
									'singular_name'      => __( 'Cause', 'Cause' ),
									//'menu_name'          => _x( 'Cause', 'Admin menu name', 'Cause' ),
									'add_new'            => __( 'Add Cause', 'Cause' ),
									'add_new_item'       => __( 'Add New Cause', 'Cause' ),
									'edit'               => __( 'Edit', 'Cause' ),
									'edit_item'          => __( 'Edit Cause', 'Cause' ),
									'new_item'           => __( 'New Cause', 'Cause' ),
									'view'               => __( 'View Causes', 'Cause' ),
									'view_item'          => __( 'View Cause', 'Cause' ),
									'search_items'       => __( 'Search Causes', 'Cause' ),
									'not_found'          => __( 'No Cause found', 'Cause' ),
									'not_found_in_trash' => __( 'No Cause found in trash', 'Cause' ),
									'parent'             => __( 'Parent Cause', 'Cause' )
								),
							'description'         => __( 'This is where you can add new Cause.', 'Cause' ),
							'public'              => true,
							'show_ui'             => true,
							'capability_type'     => 'post',
							//'show_in_menu' => 'edit.php?post_type=causes',
							'map_meta_cap'        => true,
							'publicly_queryable'  => true,
							'exclude_from_search' => false,
							'hierarchical'        => false, 
							'rewrite'             => true,
							'query_var'           => true,
							'supports'            => array( 'title', 'editor', 'thumbnail'),
							'has_archive'         => 'false',
						)
					);
			}
			/**
			 * Cause Categories
			 */
			public function cs_causes_register_categories(){
				  $labels = array(
					'name' => 'Cause Categories',
					'search_items' => 'Search Cause Categories',
					'edit_item' => 'Edit Cause Category',
					'update_item' => 'Update Cause Category',
					'add_new_item' => 'Add New Category',
					'menu_name' => 'Categories',
				  ); 	
				  register_taxonomy('causes-category',array('causes'), array(
					'hierarchical' => true,
					'labels' => $labels,
					'show_ui' => true,
					'query_var' => true,
					'rewrite' => array( 'slug' => 'causes-category' ),
				  ));
			}
			
			/**
			 * Cause Tags
			 */
			public function cs_causes_register_tags(){
				// adding tag start
				  $labels = array(
					'name' => 'Cause Tags',
					'singular_name' => 'causes-tag',
					'search_items' => 'Search Tags',
					'popular_items' => 'Popular Tags',
					'all_items' => 'All Tags',
					'parent_item' => null,
					'parent_item_colon' => null,
					'edit_item' => 'Edit Tag', 
					'update_item' => 'Update Tag',
					'add_new_item' => 'Add New Tag',
					'new_item_name' => 'New Tag Name',
					'separate_items_with_commas' => 'Separate tags with commas',
					'add_or_remove_items' => 'Add or remove tags',
					'choose_from_most_used' => 'Choose from the most used tags',
					'menu_name' => 'Tags',
				  ); 
				  register_taxonomy('causes-tag','causes',array(
					'hierarchical' => false,
					'labels' => $labels,
					'show_ui' => true,
					'update_count_callback' => '_update_post_term_count',
					'query_var' => true,
					'rewrite' => array( 'slug' => 'cause-tag' ),
				  ));
				// adding tag end
			}
			/**
			 * Hide Cause Add new link
			 */
			public function cs_addnew_cause_role() {
				
				$role = get_role( 'organizer' );
				if(!isset($role)){
					$role = add_role( 'organizer', 'Organizer', array(
						'read' => true, // True allows that capability
						'write' => true, // True allows that capability
						'edit_posts'   => true,
						'delete_posts' => false, // Use false to explicitly deny
					) );
				}
			}
			
			/**
			 * hook into WP's admin_init action hook
			 */
			public function cs_cause_admin_init()
			{           
				
				add_action('wp_ajax_add_cause_donation_to_list', array(&$this, 'add_cause_donation_to_list'));
				// Add metaboxes
				add_action('add_meta_boxes', array(&$this, 'cs_meta_cause_add'));
			}
			/**
			 * hook into WP's add_meta_boxes action hook
			*/
			public function cs_meta_cause_add()
			{  
				add_meta_box( 'cs_meta_cause', 'Cause Options', array(&$this, 'cs_meta_cause'), 'causes', 'normal', 'high' );  
			}
			
			/**
			 * Cause meta Fields
			*/
			public function cs_meta_cause( $post )
			{
				global $post,$cs_xmlObject, $cs_xmlObject_transaction;
				$cs_theme_options=get_option('cs_theme_options');
				$cs_header_position =$cs_theme_options['cs_header_position'];
				$cause_post_id = $post->ID;
				$cs_builtin_seo_fields =$cs_theme_options['cs_builtin_seo_fields'];
				$cs_cause = get_post_meta($post->ID, "cs_cause_meta", true);
				if ( $cs_cause <> "" ) {
					$cs_xmlObject = new SimpleXMLElement($cs_cause);
				}
			?>		
                <div class="page-wrap page-opts left" style="overflow:hidden; position:relative; height: 1432px;">
                    <div class="option-sec" style="margin-bottom:0;">
                        <div class="opt-conts">
                            <div class="elementhidden">
                                <div class="tabs vertical">
                                    <nav class="admin-navigtion">
                                        <ul id="myTab" class="nav nav-tabs">
                                        	<?php
											if ( function_exists( 'cs_general_settings_element' ) ||  function_exists( 'cs_sidebar_layout_options' )) { 
											?>
                                            <li class="active"><a href="#tab-general-settings" data-toggle="tab"><i class="fa fa-cog"></i> General</a></li>
                                            <?php
											}
 											if ( function_exists( 'cs_subheader_element' )) { 
												?>
                                            	<li><a href="#tab-subheader-options" data-toggle="tab"><i class="fa fa-indent"></i> Sub Header </a></li>
                                            	<?php
											}
											if(isset($cs_builtin_seo_fields) && $cs_builtin_seo_fields == 'on' && function_exists( 'cs_seo_settitngs_element' )){
												?>
                                            	<li><a href="#tab-seo-advance-settings" data-toggle="tab"><i class="fa fa-dribbble"></i> SEO Options</a></li>
                                            	<?php 
											}
											?>
                                            <li><a href="#tab-causes-options" data-toggle="tab"><i class="fa fa-angellist"></i> Causes Options </a></li>
                                          
                                            <li><a href="#tab-member-settings" data-toggle="tab"><i class="fa fa-database"></i>Donations</a></li>
                                           
                                      </ul>
                                  </nav>
                                    <div class="tab-content">
                                    <?php
									if ( function_exists( 'cs_subheader_element' ) ) { 
										?>
                                        <div id="tab-subheader-options" class="tab-pane fade">
                                            <?php cs_subheader_element();?>
                                        </div>
                                    	<?php 
									}
									
									if ( function_exists( 'cs_general_settings_element' ) ||  function_exists( 'cs_sidebar_layout_options' )) { 
									?>
                                        <div id="tab-general-settings" class="tab-pane fade active in">
                                            <?php 
                                                if ( function_exists( 'cs_general_settings_element' ) ) { 
                                                    cs_general_settings_element();
                                                }
                                                if ( function_exists( 'cs_sidebar_layout_options' ) ) { 
													 if ( isset($cs_theme_options['sidebar']) and count($cs_theme_options['sidebar']) > 0 ) {
                                                    	cs_sidebar_layout_options();
													 }
                                                }
                                            ?>
                                        </div>
                                     <?php
									}
									?>
                                    <div id="tab-causes-options" class="tab-pane fade">
                                    	
                                         
                                       <?php $this->cs_causes_general_settings($post->ID);?>
                                      
                                    </div>
                                   
                                    <div id="tab-member-settings" class="tab-pane fade">
                                    	
                                         <?php $this->cs_causes_donation_settings($post->ID);?>
                                            
                                    </div>
                                 
                                    <?php if(isset($cs_builtin_seo_fields) && $cs_builtin_seo_fields == 'on' && function_exists( 'cs_seo_settitngs_element' )){?>
                                        <div id="tab-seo-advance-settings" class="tab-pane fade">
                                            <?php cs_seo_settitngs_element();?>
                                        </div>
                                    <?php }?>
                                  </div>
                                </div>
                            </div>
                      </div>
                     <input type="hidden" name="cause_meta_form" value="1" />
                    </div>
                 </div>
                <div class="clear"></div>
			<?php 
            }
			/**
			 * Causes Donations Array
			 */
			public function cs_causes_donation_settings()
			{
					global $post, $cs_xmlObject,$cs_xmlObject_transaction;
					if(isset($cs_xmlObject->cs_donations_show)) $cs_donations_show = $cs_xmlObject->cs_donations_show; else $cs_donations_show = '';
					$cause_end_date = get_post_meta($post->ID, "cause_end_date", true);
					$cs_cause_percentage_amount = get_post_meta( $post->ID, 'cs_cause_percentage_amount', true);
					$cs_cause_raised_amount = get_post_meta( $post->ID, 'cs_cause_raised_amount', true);
					$cs_cause_goal_amount = get_post_meta( $post->ID, 'cs_cause_goal_amount', true);
					$payment_gross = 0;
					$percentage_amount = $payment_gross_total = 0;
					$cause_raised_amount = '0';
					$cs_cause_trans = get_option('cs_cause_transaction_meta', true);
					if ( isset($cs_cause_trans[$post->ID]) && is_array($cs_cause_trans[$post->ID]) && count($cs_cause_trans[$post->ID])>0 ) {
						foreach ( $cs_cause_trans[$post->ID] as $transct ){
								$payment_gross_total = $payment_gross_total+$transct['payment_gross'];
						}
						 $cause_raised_amount = $payment_gross_total;
					}
					if ( function_exists( 'cs_enqueue_timepicker_script' ) ) {
						cs_enqueue_timepicker_script();
					}
				?>
                <script type="text/javascript">
				 	jQuery(function(){
						 jQuery('#payment_date').datetimepicker({
							  format:'Y/m/d',
							  timepicker:false
						 });
				 	});
				</script>
                <div class="boxes tracklists">
                	<div id="add_cuase_dontations" class="poped-up">
                    	<div class="cs-heading-area">
                            <h5><i class="fa fa-plus-circle"></i>Add Donation</h5>
                            <span onclick="javascript:removeoverlay('add_cuase_dontations','append')" class="closeit cs-btnclose"> <i class="fa fa-times"></i></span>
                            <div class="clear"></div>
                          </div>
                        <ul class="form-elements">
                            <li class="to-label"><label>Username</label></li>
                            <li class="to-field select-style">
                                 <?php
                                    $blogusers = get_users('orderby=nicename');
                                    echo '<select name="user_id" id="user_id">
                                            <option value="">None</option>';
                                              foreach ($blogusers as $user) {
                                                echo '<option value="'.$user->ID.'" >'.$user->display_name.'</option>';
                                             }
                                    echo '</select>';
                                 ?>
                            </li>
                        </ul>
                        <ul class="form-elements">
                            <li class="to-label"><label>Name</label></li>
                            <li class="to-field">
                            	<input type="text" id="address_name" name="address_name" value="" />
                            </li>
                        </ul>
                        <ul class="form-elements">
                            <li class="to-label"><label>Email</label></li>
                            <li class="to-field">
                            	<input type="text" id="payer_email" name="payer_email" value="" />
                            </li>
                        </ul>
                        <ul class="form-elements">
                            <li class="to-label"><label>Amount</label></li>
                            <li class="to-field">
                            	<input type="text" id="payment_gross" name="payment_gross" value="" />
                            </li>
                        </ul>
                        <ul class="form-elements">
                            <li class="to-label"><label>Transaction ID</label></li>
                            <li class="to-field">
                            	<input type="text" id="txn_id" name="txn_id" value="" />
                            </li>
                        </ul>
                        <ul class="form-elements">
                            <li class="to-label"><label>Payment Date</label></li>
                            <li class="to-field">
                            	<input type="text" id="payment_date" name="payment_date" value="" />
                            </li>
                        </ul>
                        <ul class="form-elements noborder">
                            <li class="to-label"></li>
                            <li class="to-field"><input type="button" value="Add Donation" onclick="add_cause_donation_to_list('<?php echo esc_js(admin_url('admin-ajax.php'));?>', '<?php echo esc_js(get_template_directory_uri());?>')" /></li>
                        </ul>
                    </div>
                    <script>
						jQuery(document).ready(function($) {
							$("#total_tracks").sortable({
								cancel : 'td div.poped-up',
							});
						});
					</script>
                    <ul class="form-elements">
                        <li class="to-label">
                          <label>Donors On/Off</label>
                        </li>
                        <li class="to-field">
                          <label class="pbwp-checkbox">
                            <input type="hidden" name="cs_donations_show" value=""/>
                            <input type="checkbox" class="myClass" name="cs_donations_show" <?php if ($cs_donations_show == "on") echo "checked" ?>/>
                            <span class="pbwp-box"></span> </label>
                        </li>
                      </ul>
					 <ul class="form-elements noborder">
                        <li class="to-label">Cause Donations</li>
                        <li class="to-button"><a href="javascript:_createpop('add_cuase_dontations','filter')" class="button">Add Donation</a></li>
                    </ul>	
                    <table class="to-table" border="0" cellspacing="0">
                        <thead>
                            <tr>
                                <th style="width:20%;">Donor Name</th>
                                <th style="width:20%;">Email</th>
                                <th style="width:20%;">Amount</th>
                                <th style="width:20%;">Transaction ID</th>
                                <th style="width:20%;">Date</th>
                                <th style="width:20%;" class="centr">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="total_cause_donations">
                            <?php
								global $counter_donation, $user_id, $item_name, $address_name, $payer_email, $payment_gross, $txn_id, $payment_date;
								$counter_donation = $post->ID;
								$cs_cause_trans = get_option('cs_cause_transaction_meta', true);
								if ( isset($cs_cause_trans[$post->ID]) && is_array($cs_cause_trans[$post->ID]) && count($cs_cause_trans[$post->ID])>0 ) {
									foreach ( $cs_cause_trans[$post->ID] as $transct ){
											$user_id = $transct['user_id'];
											if(isset($transct['item_name']))
												$item_name = $transct['item_name'];
											else 
												$item_name = '';
											$address_name = $transct['address_name'];
											$payer_email = $transct['payer_email'];
											$payment_gross = $transct['payment_gross'];
											$txn_id = $transct['txn_id'];
											$payment_date = $transct['payment_date'];
											$counter_donation++;
 											$this->add_cause_donation_to_list();
									}
								}
							?>
                        </tbody>
                    </table>
                </div>
                <div class="clear"></div>
                <?php
			}
			/**
			 * Causes Donations
			 */
			public function add_cause_donation_to_list()
			{
					global $counter_donation, $user_id, $item_name, $address_name, $payer_email, $payment_gross, $txn_id, $payment_date;
					foreach ($_POST as $keys=>$values) {
						$$keys = $values;
					}
					?>
					<tr class="parentdelete color-title" id="edit_track<?php echo esc_attr($counter_donation);?>">
						<td id="address_name<?php echo absint($counter_donation);?>" style="width:20%;"><?php echo esc_attr($address_name);?></td>
						<td id="payer_email<?php echo absint($counter_donation);?>" style="width:20%;"><?php echo esc_attr($payer_email);?></td>
						<td id="payment_gross<?php echo absint($counter_donation);?>" style="width:20%;"><?php echo esc_attr($payment_gross);?></td>
						<td id="txn_id<?php echo absint($counter_donation);?>" style="width:20%;"><?php echo esc_attr($txn_id);?></td>
						<td id="payment_date<?php echo absint($counter_donation);?>" style="width:20%;"><?php echo esc_attr($payment_date);?></td>
						<td class="centr" style="width:20%;">
							<a href="javascript:_createpop('edit_track_form<?php echo esc_js($counter_donation);?>','filter')" class="actions edit">&nbsp;</a> <a href="#" class="delete-it btndeleteit actions delete">&nbsp;</a>
                            <div class="poped-up padding-none" id="edit_track_form<?php echo absint($counter_donation);?>">
                              <div class="cs-heading-area">
                                <h5><i class="fa fa-plus-circle"></i> Donation Settings</h5>
                                <span onclick="javascript:removeoverlay('edit_track_form<?php echo esc_js($counter_donation);?>','append')" class="closeit cs-btnclose"> <i class="fa fa-times"></i></span>
                                <div class="clear"></div>
                              </div>
                                <ul class="form-elements">
                                    <li class="to-label"><label>Username</label></li>
                                    <li class="to-field select-style">
                                         <?php
                                            $blogusers = get_users('orderby=nicename');
                                             echo '<select name="user_id[]" id="user_id">
                                                    <option value="">None</option>';
                                                      foreach ($blogusers as $user) {
                                                        if($user->ID=="$user_id"){
                                                            $selected =' selected="selected"';
                                                        }else{ 
                                                            $selected = '';
                                                        }
                                                        echo '<option value="'.$user->ID.'" '.$selected.'>'.$user->display_name.'</option>';
                                                    }
                                             echo '</select>';
                                         ?>
                                    </li>
                                </ul>
                               <input type="hidden" name="item_name[]" value="<?php echo htmlspecialchars($item_name)?>"  id="item_name<?php echo absint($counter_donation)?>" />
								<ul class="form-elements">
									<li class="to-label"><label>Donar Name</label></li>
									<li class="to-field"><input type="text" name="address_name[]" value="<?php echo htmlspecialchars($address_name)?>" id="address_name<?php echo absint($counter_donation)?>" /></li>
								</ul>
								<ul class="form-elements">
									<li class="to-label"><label>Email</label></li>
									<li class="to-field"><input type="text" name="payer_email[]" value="<?php echo htmlspecialchars($payer_email)?>" id="payer_email<?php echo absint($counter_donation);?>" /></li>
								</ul>
								<ul class="form-elements">
									<li class="to-label"><label>Amount</label></li>
									<li class="to-field"><input type="text" name="payment_gross[]" value="<?php echo htmlspecialchars($payment_gross)?>" id="payment_gross<?php echo absint($counter_donation);?>" /></li>
								</ul>
								<ul class="form-elements">
									<li class="to-label"><label>Transaction ID</label></li>
									<li class="to-field"><input type="text" name="txn_id[]" value="<?php echo htmlspecialchars($txn_id)?>" id="txn_id<?php echo absint($counter_donation);?>" /></li>
								</ul>
								<ul class="form-elements">
									<li class="to-label"><label>Donation Date</label></li>
									<li class="to-field">
                                    <script type="text/javascript">
										jQuery(function(){
											 jQuery('#payment_date<?php echo absint($counter_donation);?>').datetimepicker({
												  format:'Y/m/d',
												  timepicker:false
											 });
										});
									</script>
                                    <input type="text" name="payment_date[]" value="<?php echo htmlspecialchars($payment_date)?>" id="payment_date<?php echo absint($counter_donation);?>" /></li>
								</ul>
								<ul class="form-elements noborder">
									<li class="to-label"><label></label></li>
									<li class="to-field">
                                    <input type="button" value="Update Donation" onclick="removeoverlay('edit_track_form<?php echo esc_js($counter_donation)?>','append')" />
                                    </li>
								</ul>
							</div>
						</td>
					</tr>
				<?php
				$user_id = '';
				if(isset($action)) die();
			}
			
			/**
			 * Causes Meta attributes Array
			 */
			public function cs_causes_meta_attributes()
			{
				return array(
							'title'=>'Causes Options',
							'description'=>'',
							'meta_attributes' => array(
								'cause_goal_amount' => array(
									'name' => 'cause_goal_amount',
									'type' => 'text',
									'id' => 'cause_goal_amount',
									'title' => 'Goal Amount',
									'description' => '',
									
								),
								'cause_end_date' => array(
									'name' => 'cause_end_date',
									'type' => 'date',
									'id' => 'cause_goal_amount',
									'title' => 'Cause End Date',
									'description' => '',
									
								),
								'cause_paypal_email' => array(
									'name' => 'cause_paypal_email',
									'type' => 'text',
									'id' => 'cause_paypal_email',
									'title' => 'Paypal Email',
									'description' => '',
									
								),
								'cause_paypal_email' => array(
									'name' => 'cause_paypal_email',
									'type' => 'text',
									'id' => 'cause_paypal_email',
									'title' => 'Paypal Email',
									'description' => '',
									
								),
								'var_cp_assignment_file' => array(
									'name' => 'var_cp_assignment_file',
									'type' => 'file',
									'id' => 'var_cp_assignment_file',
									'title' => 'Attach Assignment',
									'description' => '',
									'value' => '',
									
								),
								'assignment_form' => array(
									'name' => 'assignment_form',
									'type' => 'hidden',
									'id' => '',
									'title' => '',
									'description' => '',
									'value' => '1',
								),
							),
						);	
			}
			
		   /**
			* Causes general Settings
		   */
			public function cs_causes_general_settings($cause_post_id=''){
				global $post, $cs_xmlObject,$cs_xmlObject_transaction;
					$cause_end_date = get_post_meta($post->ID, "cause_end_date", true);
					$cs_cause_percentage_amount = get_post_meta( $post->ID, 'cs_cause_percentage_amount', true);
					$cs_cause_raised_amount = get_post_meta( $post->ID, 'cs_cause_raised_amount', true);
					$cs_cause_goal_amount = get_post_meta( $post->ID, 'cs_cause_goal_amount', true);
					$cause_organizer = get_post_meta( $post->ID, 'cause_organizer', true);
					
					//cause_organizer
					//echo 'percentag: '.$cs_cause_percentage_amount.'===raised: '.$cs_cause_raised_amount.'======= goal'. $cs_cause_goal_amount;
					
					$payment_gross = 0;
					$cause_raised_amount = 0;
					$percentage_amount = $payment_gross_total = 0;
					$cs_cause_trans = get_option('cs_cause_transaction_meta', true);
					if ( isset($cs_cause_trans[$post->ID]) && is_array($cs_cause_trans[$post->ID]) && count($cs_cause_trans[$post->ID])>0 ) {
						foreach ( $cs_cause_trans[$post->ID] as $transct ){
								$payment_gross_total = $payment_gross_total+$transct['payment_gross'];
						}
						 $cause_raised_amount = $payment_gross_total;
					}
					if ( function_exists( 'cs_enqueue_timepicker_script' ) ) {
						cs_enqueue_timepicker_script();
					}
					if ( empty($cs_xmlObject->cause_goal_amount) ) $cause_goal_amount = ""; else $cause_goal_amount = $cs_xmlObject->cause_goal_amount;
					if ( empty($cs_xmlObject->cause_end_date) ) $cause_end_date = ""; else $cause_end_date = $cs_xmlObject->cause_end_date;
					if ( empty($cs_xmlObject->cause_end_date) ) $cause_end_date = ""; else $cause_end_date = $cs_xmlObject->cause_end_date;
					if ( empty($cs_xmlObject->cause_paypal_email) ) $cause_paypal_email = ""; else $cause_paypal_email = $cs_xmlObject->cause_paypal_email;
					if ( empty($cs_xmlObject->cause_organizer) ) $cause_organizer = ""; else $cause_organizer = $cs_xmlObject->cause_organizer;
					
				?>
                	<script type="text/javascript">
						jQuery(function(){
							 jQuery('#cause_end_date').datetimepicker({
								  format:'Y/m/d',
								  timepicker:false
							 });
						});
					</script>
                		<ul class="form-elements">
                            <li class="to-label"><label>Select Organizer</label></li>
                            <li class="to-field select-style">
                            <?php
                                $blogusers = get_users('orderby=nicename');
                                echo '<select name="cause_organizer" id="cause_organizer">
                                        <option value="">None</option>';
                                          foreach ($blogusers as $user) {
                                        
                                        if($user->ID=="$cause_organizer"){
                                            $selected =' selected="selected"';
                                        }else{ 
                                            $selected = '';
                                        }
                                        echo '<option value="'.$user->ID.'" '.$selected.'>'.$user->display_name.'</option>';
                                        
                                }
                                echo '</select>';
                            ?>
                            </li>
                         </ul>
                        <ul class="form-elements">
                            <li class="to-label"><label>Cause End Date</label></li>
                            <li class="to-field">
                            	<input type="text" id="cause_end_date" name="cause_end_date" value="<?php echo esc_attr($cause_end_date);?>" />
                            </li>
                        </ul>
                        <ul class="form-elements">
                            <li class="to-label"><label>Goal Amount</label></li>
                            <li class="to-field"><input type="text" name="cause_goal_amount" value="<?php echo htmlspecialchars($cause_goal_amount)?>" /></li>
                        </ul>
                        <ul class="form-elements">
                            <li class="to-label"><label>Paypal Email</label></li>
                            <li class="to-field"><input type="text" name="cause_paypal_email" value="<?php echo htmlspecialchars($cause_paypal_email)?>" /><p> Please enter your paypal bussiness email for individual Cause. If you dont enter paypal email here. You must enter paypal email at theme options <?php //echo '<a target="_blank" href="' . get_admin_url() . 'themes.php?page=cs_theme_options#tab-paypalapi-key-show">' . __('here', 'Cause') . '.</a>';?> that will be used for default for all cuases.</p></li>
                        </ul>
                        <ul class="form-elements">
                            <li class="to-label"><label>Raised Amount</label></li>
                            <li class="to-field"><input type="text" disabled="disabled" name="cause_raised_amount" value="<?php echo htmlspecialchars($cause_raised_amount)?>" /><p> Auto Calculated Raised Amount From Donations</p></li>
                        </ul>
                <?php	
			}
			
			/**
			* Causes Meta option save
		    */
			public function cs_meta_causes_save( $post_id ){  
				  $sxe = new SimpleXMLElement("<cause></cause>");
				  if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;  
					if ( function_exists( 'cs_page_options_save_xml' ) ) {
						$sxe = cs_page_options_save_xml($sxe);
					}
					$payment_gross=0;
					if ( empty($_POST["cause_goal_amount"]) ) $_POST["cause_goal_amount"] = "";
					if ( empty($_POST["cause_end_date"]) ) $_POST["cause_end_date"] = "";
					if ( empty($_POST["cause_raised_amount"]) ) $_POST["cause_raised_amount"] = "";
					if ( empty($_POST["cause_paypal_email"]) ) $_POST["cause_paypal_email"] = "";
					if ( empty($_POST["cs_donations_show"]) ) $_POST["cs_donations_show"] = "";
					if ( empty($_POST["cause_organizer"]) ) $_POST["cause_organizer"] = "";
					$sxe->addChild('cause_goal_amount', htmlspecialchars($_POST['cause_goal_amount']) );
					$sxe->addChild('cause_end_date', htmlspecialchars($_POST['cause_end_date']) );
					$sxe->addChild('cause_paypal_email', htmlspecialchars($_POST['cause_paypal_email']) );
					$sxe->addChild('cs_donations_show', htmlspecialchars($_POST['cs_donations_show']) );
					$sxe->addChild('cause_organizer', htmlspecialchars($_POST['cause_organizer']) );
					$cs_counter = 0;
					$transaction_array = array();
					$transaction_cause_array = array();
					if ( isset($_POST['address_name']) && is_array($_POST['address_name'])) {
						
						foreach ( $_POST['address_name'] as $count ){
								$transaction_cause_array = array();
								$payment_gross = $payment_gross+$_POST['payment_gross'][$cs_counter];
								if(isset($_POST['item_name'][$cs_counter]) && $_POST['item_name'][$cs_counter] <> ''){
									$transaction_cause_array['item_name'] = esc_attr($_POST['item_name'][$cs_counter]);
								} else {
									$transaction_cause_array['item_name'] = get_the_title($post_id);
								}
								$transaction_cause_array['user_id'] = absint($_POST['user_id'][$cs_counter]);
								$transaction_cause_array['txn_id'] = esc_attr($_POST['txn_id'][$cs_counter]);
								$transaction_cause_array['payment_date'] = esc_attr($_POST['payment_date'][$cs_counter]);
								$transaction_cause_array['payer_email'] = esc_attr($_POST['payer_email'][$cs_counter]);
								$transaction_cause_array['payment_gross'] = esc_attr($_POST['payment_gross'][$cs_counter]);
								$transaction_cause_array['address_name'] = esc_attr($_POST['address_name'][$cs_counter]);
								$transaction_array[] = $transaction_cause_array;
								$cs_counter++;
						}
					}
					$cs_cause_transaction_meta = get_option('cs_cause_transaction_meta', true);
					if(is_int($cs_cause_transaction_meta)){
						$cs_cause_transaction_meta = array();
					}
					if(!isset($cs_cause_transaction_meta) || empty($cs_cause_transaction_meta) || !is_array($cs_cause_transaction_meta)){
						$cs_cause_transaction_meta = array();
					}
					$cs_cause_transaction_meta[$post_id] = $transaction_array;
					$cs_cause_transaction_meta = update_option('cs_cause_transaction_meta', $cs_cause_transaction_meta);
					$percentage_amount = 100;
					$percentage_amount = round(($payment_gross/htmlspecialchars($_POST['cause_goal_amount']))*100);
					if(isset($percentage_amount) && !empty($percentage_amount)){
						if($percentage_amount>=100){
							$percentage_amount = 100;
						}
					}
					update_post_meta( $post_id, 'cs_cause_percentage_amount', esc_attr($percentage_amount) );
					update_post_meta( $post_id, 'cause_organizer', htmlspecialchars($_POST['cause_organizer']) );
					update_post_meta( $post_id, 'cs_cause_goal_amount', htmlspecialchars($_POST['cause_goal_amount']) );
					update_post_meta( $post_id, 'cs_cause_raised_amount', esc_attr($payment_gross) );
					update_post_meta( $post_id, 'cause_end_date', htmlspecialchars($_POST['cause_end_date']) );
					update_post_meta( $post_id, 'cs_cause_meta', $sxe->asXML() );
			}
		} // END class
	}