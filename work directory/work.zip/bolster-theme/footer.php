	</div>
    <!-- Content Section End -->
</div>

<?php 
cs_footer_settings();
wp_footer();?>
<!-- Wrapper End -->
</body>
</html>
