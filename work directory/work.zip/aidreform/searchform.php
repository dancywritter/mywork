<form id="searchform" method="get" action="<?php echo home_url()?>"  role="search">
	<input name="s" id="searchinput" value="<?php _e('Search for:', 'AidReform'); ?>" type="text" />
    <input type="submit" class="backcolr uppercase" id="searchsubmit"  value="<?php _e('Search', 'AidReform'); ?>" />
</form>
