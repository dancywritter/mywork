<?php
/**
 * The template for displaying Achive(s) for auther(s) page
 *
 */
	get_template_part("archive", "page");
?>