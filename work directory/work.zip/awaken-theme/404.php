<?php
/**
 * The template for displaying 404 pages (Not Found)

 */
	global  $cs_theme_options;
	
?>
<!-- Columns Start - fullwidth -->
<!-- Page Contents Start -->
       <?php echo cs_page_404(); ?>
<!-- Page Contents End -->