var $ = jQuery;
jQuery(document).ready(function($) {
	jQuery("body").addClass("woocommerce");
});