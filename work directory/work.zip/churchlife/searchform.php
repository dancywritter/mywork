<form id="searchform" method="get" action="<?php echo home_url()?>"  role="search">
	<input name="s" id="searchinput" value="<?php _e('Search for:', 'Church Life'); ?>" type="text" />
    <label><input type="submit" class="backcolr uppercase" id="searchsubmit"  value="<?php _e('Search', 'Church Life'); ?>" /></label>
</form>
