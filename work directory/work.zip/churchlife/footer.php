    </div>
   </div>
<!-- CopyRight End --> 
 <div class="clear"></div>
</div>
<!-- Wrapper End -->
<?php 
px_footer_settings();
wp_footer();?>
</body>
</html>